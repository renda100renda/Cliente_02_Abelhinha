import { UnitInfo, Review, ServiceItem } from '../types';

export const UNITS: Record<'morumbi' | 'vila-sonia', UnitInfo> = {
  'morumbi': {
    id: 'morumbi',
    name: 'Morumbi / Vila Suzana',
    fullName: 'AUpetMIAU Morumbi',
    rating: 4.8,
    reviewCount: 43,
    address: 'R. Mal. Hastimphilo de Moura, 277 - Vila Suzana',
    neighborhood: 'Vila Suzana / Morumbi, São Paulo - SP',
    cep: '05641-000',
    phone: '(11) 96708-7583',
    phoneRaw: '5511967087583',
    whatsappLink: 'https://wa.me/5511967087583?text=Ol%C3%A1%2C%20vim%20pelo%20site%20da%20AUpetMIAU%20Morumbi%20e%20gostaria%20de%20agendar%20um%20hor%C3%A1rio%20de%20SPA%2FBanho%20para%20meu%20pet!',
    googleMapsUrl: 'https://maps.google.com/?q=R.+Mal.+Hastimphilo+de+Moura,+277+-+Vila+Suzana,+São+Paulo+-+SP,+05641-000',
    hours: 'Terça a Sábado: 09:00 às 18:00',
    highlights: ['4,8 Estrelas no Google', 'Pet livre pela loja', 'Leva e Traz Táxi Dog', 'Espaço Inclusivo']
  },
  'vila-sonia': {
    id: 'vila-sonia',
    name: 'Vila Sônia',
    fullName: 'AUpetMIAU Boutique & SPA II',
    rating: 5.0,
    reviewCount: 86,
    address: 'Rua Dr. Sílvio Dante Bertacchi, 534 - Vila Sônia',
    neighborhood: 'Vila Sônia, São Paulo - SP',
    cep: '05625-000',
    phone: '(11) 99765-4154',
    phoneRaw: '5511997654154',
    whatsappLink: 'https://wa.me/5511997654154?text=Ol%C3%A1%2C%20vim%20pelo%20site%20da%20AUpetMIAU%20Vila%20S%C3%B4nia%20e%20gostaria%20de%20agendar%20um%20hor%C3%A1rio%20de%20SPA%2FBanho%20para%20meu%20pet!',
    googleMapsUrl: 'https://maps.google.com/?q=Rua+Dr.+S%C3%ADlvio+Dante+Bertacchi,+534+-+Vila+Sonia,+São+Paulo+-+SP,+05625-000',
    hours: 'Terça a Sábado: 09:00 às 18:00',
    highlights: ['Nota Máxima 5,0 no Google', 'Especialistas em Cães Reativos', 'Tosa na Tesoura', 'Envio de Fotos Fofas']
  }
};

export const REVIEWS: Review[] = [
  {
    id: '1',
    author: 'Amanda Morelli',
    role: 'Tutora do Charlie (Spitz Alemão)',
    rating: 5.0,
    timeAgo: 'Avaliação verificada no Google',
    text: 'Encontrei o lugar ideal para banho do meu Charlie! Ele era um cão reativo com banho fora de casa e desde o primeiro banho na AUpetMIAU ele ficou super bem! Tosa higiênica feita de acordo com o padrão da raça dele (spitz alemão) na tesoura. As fotos que eles enviam são demais!',
    petName: 'Charlie',
    breed: 'Spitz Alemão',
    unit: 'Vila Sônia',
    ownerResponse: 'Charlie é muito querido e Amanda muito obrigado pela avaliação!'
  },
  {
    id: '2',
    author: 'Grégory Esgaib',
    role: 'Local Guide · 19 avaliações',
    rating: 5.0,
    timeAgo: 'Avaliação verificada no Google',
    text: 'Melhor pet shop da Vila Sônia, sem dúvida! Atendimento impecável, equipe extremamente caprichosa e atenciosa. Dá pra ver que eles realmente respeitam e cuidam dos pets com muito carinho, como se fossem deles.',
    unit: 'Vila Sônia'
  },
  {
    id: '3',
    author: 'Andrea Macedo',
    role: 'Local Guide · 220 avaliações · Tutora da Malu',
    rating: 5.0,
    timeAgo: 'Avaliação verificada no Google',
    text: 'Excelente profissionais de banho, tosa e cuidados com os pets. Minha Malu sempre sai linda e cheirosa de lá. Ainda posso contar com o serviço de leva e trás que me ajuda muito com a correria do dia a dia. Dá para notar o carinho deles no atendimento. Super recomendo!',
    petName: 'Malu',
    unit: 'Vila Sônia',
    ownerResponse: 'Andrea, seu feedback é muito importante para gente. Malu é muito querida por toda equipe ❤️'
  },
  {
    id: '4',
    author: 'Cliente Verificado Morumbi',
    role: 'Tutor de Pet no Morumbi',
    rating: 5.0,
    timeAgo: 'Avaliação no Google Maps',
    text: 'Do táxi Dog, à recepção, ao moço que dá banho: tudo impecável! Atenciosos, carinhosos, produtos de alta qualidade e minha pet fica solta pela loja sem o sofrimento de ficar enjaulada.',
    unit: 'Morumbi'
  },
  {
    id: '5',
    author: 'Tutor AUpetMIAU',
    role: 'Cliente Fiel',
    rating: 5.0,
    timeAgo: 'Avaliação no Google Maps',
    text: 'Ambiente fantástico e profissionais competentes. O motorista do táxi é super cuidadoso e trata meu cachorro com muito carinho. E ainda mandam fotos super fofas após o banho pra gente se derreter!',
    unit: 'Vila Sônia'
  }
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'spa-bath',
    name: 'Banho SPA Terapêutico & Hidratação',
    tagline: 'Cuidado aromático com água morninha na temperatura perfeita e massagem relaxante',
    description: 'Indicado para quem quer o pet macio, cheiroso por dias e sem irritações cutâneas. Utilizamos cosmética nobre hipoalergênica e secagem com temperatura controlada.',
    deliverables: [
      'Banho com água morna e shampoo hipoalergênico suave',
      'Massagem calmante corporal durante a higienização',
      'Hidratação profunda da pelagem com máscara nutritiva',
      'Limpeza de ouvidos e corte/lixamento delicado de unhas',
      'Secagem sem barulho excessivo e escovação desembaraçante',
      'Sessão de fotos fofas enviada direto no seu WhatsApp'
    ],
    recommendedFor: 'Todos os cães e gatos que merecem relaxamento de verdade',
    iconName: 'Sparkles'
  },
  {
    id: 'scissor-grooming',
    name: 'Tosa Boutique na Tesoura (Padrão da Raça)',
    tagline: 'Escultura manual anatômica que valoriza o porte e protege a saúde da pele',
    description: 'Nossos groomers são especializados em tesoura para raças de pelagem nobre (Spitz Alemão, Poodle, Maltês, Shih-tzu, Schnauzer). Nunca raspamos o subpêlo protetor.',
    deliverables: [
      'Análise prévia da densidade e padrão da raça',
      'Escultura 100% manual na tesoura para contornos perfeitos',
      'Preservação do subpêlo protetor contra alopécia pós-tosa',
      'Tosa higiênica de alta precisão sem ferir áreas sensíveis',
      'Finalização com perfume nobre suave e laço/gravatinha cortesia',
      'Relatório visual com foto profissional de estúdio'
    ],
    recommendedFor: 'Spitz Alemão, Maltês, Poodles, Shih-tzu e raças com pelagem sensível',
    iconName: 'Scissors'
  },
  {
    id: 'reactive-care',
    name: 'Atendimento para Cães Reativos & Ansiosos',
    tagline: 'Paciência, respeito ao ritmo do animal e zero contenção agressiva',
    description: 'Para cães que têm pavor de banho em pet shops barulhentos. Aqui seu pet é dessensibilizado com carinho, petiscos e tempo dedicado, sem pressa de esteira mecânica.',
    deliverables: [
      'Zero gaiolas ou baias metálicas fechadas',
      'Tempo de adaptação com cheiros e carinho antes da água',
      'Profissionais experientes em comportamento canino',
      'Acompanhamento calmo sem secadores industriais estridentes',
      'Pet livre para circular e relaxar após o término',
      'Feedback honesto do comportamento no WhatsApp'
    ],
    recommendedFor: 'Cães idosos, filhotes na primeira visita ou pets traumatizados por outros pet shops',
    iconName: 'HeartHandshake'
  },
  {
    id: 'taxi-dog',
    name: 'Táxi Dog VIP Leva & Traz',
    tagline: 'Segurança, pontualidade e motorista afetuoso na porta da sua casa',
    description: 'Atendemos Morumbi, Vila Suzana, Vila Sônia, Portal do Morumbi, Panamby e imediações. Transporte individualizado, higienizado e climatizado.',
    deliverables: [
      'Transporte climatizado com caixas limpas e cintos adaptados',
      'Motorista carinhoso e experiente com animais',
      'Avisos de saída e chegada em tempo real via WhatsApp',
      'Comodidade total sem você perder tempo no trânsito',
      'Retorno pontual com o pet cheiroso e feliz',
      'Atendimento em condomínios e residências'
    ],
    recommendedFor: 'Tutores com rotina corrida que não abrem mão da segurança do pet',
    iconName: 'Car'
  }
];

export const FAQ_ITEMS = [
  {
    question: 'Os pets realmente não ficam em gaiolas?',
    answer: 'Sim! Esse é um dos nossos maiores princípios na AUpetMIAU. Não utilizamos baias ou gaiolas fechadas. Os pets ficam soltos no espaço social da loja, interagindo com nossa equipe com total segurança e respeito ao espaço deles, reduzindo o estresse e a ansiedade a zero.'
  },
  {
    question: 'Meu cão é medroso ou reativo com banho. Vocês conseguem atender?',
    answer: 'Com certeza! Temos vasta experiência comprovada com cães reativos (como a história real do cãozinho Charlie relatada no Google Maps). Nossa equipe trabalha com dessensibilização amorosa, paciência, petiscos e respeito ao limite do animal. Nunca forçamos procedimentos.'
  },
  {
    question: 'Como funciona o serviço de Táxi Dog (Leva & Traz)?',
    answer: 'Nosso motorista busca seu pet no conforto da sua casa ou condomínio no Morumbi, Vila Suzana, Vila Sônia e arredores, em veículo climatizado e seguro. Após todo o ritual de SPA e a sessão de fotos, levamos ele de volta limpinho e relaxado. Você recebe atualizações pelo WhatsApp.'
  },
  {
    question: 'Vocês realizam tosa na tesoura para Spitz Alemão e outras raças nobres?',
    answer: 'Sim! Nossos profissionais são capacitados no padrão internacional das raças. Para o Spitz Alemão (Lulu da Pomerânia), fazemos tosa anatômica na tesoura, preservando a camada dupla de subpêlo essencial para a saúde e proteção térmica do cão, sem risco de alopécia.'
  },
  {
    question: 'Como faço para receber as fotos do meu pet após o banho?',
    answer: 'Faz parte do nosso carinho! Ao término do banho e tosa, nossa equipe faz fotos e vídeos fofos do seu pet arrumadinho e cheiroso e envia instantaneamente no seu WhatsApp para você ver o resultado antes mesmo de ele chegar em casa.'
  },
  {
    question: 'Como agendar e qual unidade escolher?',
    answer: 'Você pode escolher a unidade mais conveniente: Unidade I no Morumbi (Vila Suzana) na R. Mal. Hastimphilo de Moura, 277 ou Unidade II na Vila Sônia na Rua Dr. Sílvio Dante Bertacchi, 534. Basta clicar no botão de WhatsApp para falar diretamente com nossa equipe e reservar o melhor horário.'
  }
];
