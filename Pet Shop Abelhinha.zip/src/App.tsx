import React, { useEffect, useState } from 'react';

// Mascote oficial em PNG sem fundo
import beeCatMascotImg from './assets/images/bee_cat_mascot_transparent.png';

const REVIEWS_DATA = [
  {
    name: "Andréia Oliveira",
    text: "Eu super indico o Pet Shop Abelhinha! Meu Bobynho foi muito bem recebido e atendido, afinal de contas o cliente é ele e não eu... Eu vejo amor e carinho no cuidado com cada pet. Muito obrigada Tais e equipe por toda atenção."
  },
  {
    name: "STARdOTE",
    text: "Atendimento impecável! Taís é extremamente atenciosa, rápida e cuidadosa — dá pra sentir que ama o que faz. O Pet Shop Abelhinha é sinônimo de confiança, carinho e profissionalismo."
  },
  {
    name: "Aline Carvalho",
    text: "Meu cachorro Aladim é sempre bem tratado quando utilizamos o pet shop e retorna bem cheiroso."
  },
  {
    name: "Rafael Ribeiro Silva",
    text: "Lugar muito bem montado, com excelente atendimento e qualidade."
  },
  {
    name: "Livia Gimenes",
    text: "Atendimento individualizado, um cão por vez, deixo minha cadelinha lá sem medo e volto pra buscar. Ela fica solta. Usam produtos de qualidade e muito cheirosos que não dão alergia. Taís é incrível e atenciosa."
  },
  {
    name: "Alyoscha Stepper",
    text: "Meu dálmata sempre fica ansioso para ir ao pet shop. Ele sempre fica com um cheiro maravilhoso depois do banho e tosa."
  },
  {
    name: "Marcela Spencer",
    text: "O Abelhinha é um lugar de total confiança! Meus pets se sentem super à vontade, livres, sem qualquer sinal de estresse ou trauma. Receberam muito carinho, massagens, e o banho e a tosa higiênica são sempre impecáveis."
  },
  {
    name: "Fernanda Turolla",
    text: "Levei meus 3 pets lá e fiquei apaixonada, pelo amor, carinho e dedicação que eles têm pelos pets. Ambiente limpo, profissionais fantásticos e eles não fazem sobre demanda, cada horário tem um pet, não ficam presos em gaiolas."
  },
  {
    name: "Felipe Pastori",
    text: "A Taís é uma pessoa maravilhosa. É o lugar preferido disparado do meu cachorro até hoje. O lugar é muito agradável, convidativo e bem decorado; pelas bandanas e enfeites fashions e carinhosos que o deixam ainda mais vaidoso."
  },
  {
    name: "Andressa Duarte",
    text: "Sou mamãe de um cachorro extremamente bravo, e não conseguia achar nenhum Pet para cuidar dele na região da Vila Sônia! Até encontrar vocês, seu dog lá é tratado com muito amor, mesmo com meu cachorro super agressivo elas conquistaram ele e a mim."
  },
  {
    name: "Daniel Rangel",
    text: "Melhor Banho da região. Excelente recepção e tratamento com meus cachorros. Os animais ficam em um local acolhedor e são muito bem tratados."
  },
  {
    name: "Ivone Batista de Freitas",
    text: "Taís cuida do meu bebê Woody como se fosse o único, super carinhosa, capricha no banho, tosa higiênica, hidratação, me entrega todo cheiroso e super hidratado! Recomendo de olhos fechados!"
  }
];

export default function App() {
  // Booking state
  const [petType, setPetType] = useState('Cachorro');
  const [services, setServices] = useState<string[]>(['Banho & Tosa']);
  const [customService, setCustomService] = useState('');
  const [isCustomOpen, setIsCustomOpen] = useState(false);
  const [petSize, setPetSize] = useState<string | null>(null);
  const [prefDay, setPrefDay] = useState('Terça a Sexta');
  const [prefPeriod, setPrefPeriod] = useState('Manhã');

  // Carousel state
  const [currentSlide, setCurrentSlide] = useState(0);

  // Scroll state
  const [isScrolled, setIsScrolled] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY;
      setIsScrolled(y > 40);
      setShowBackToTop(y > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Carousel autoplay
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % REVIEWS_DATA.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const toggleService = (val: string) => {
    if (val === 'Outro/Personalizado') {
      setIsCustomOpen(!isCustomOpen);
    }
    setServices((prev) => {
      if (prev.includes(val)) {
        return prev.filter((s) => s !== val);
      } else {
        return [...prev, val];
      }
    });
  };

  const isFormValid = services.length > 0 && petSize !== null;

  const buildBookingMessage = () => {
    const servicesFormatted = services
      .map((s) => (s === 'Outro/Personalizado' && customService ? `Outro (${customService})` : s))
      .join(', ') || '(selecione o serviço)';
    const sizeFormatted = petSize || '(selecione o porte)';
    const prefFormatted = `${prefDay} pela ${prefPeriod.toLowerCase()}`;
    return `Olá! Vim pelo site do Abelhinha Pet Shop e gostaria de agendar um atendimento. • Tipo: ${petType} • Serviço: ${servicesFormatted} • Porte: ${sizeFormatted} • Preferência: ${prefFormatted}`;
  };

  const handleSendWhatsApp = () => {
    if (!isFormValid) return;
    const msg = buildBookingMessage();
    const url = `https://wa.me/5511983523034?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-[#232220] font-sans antialiased selection:bg-[#F6B81D] selection:text-[#1F1D1A]">
      {/* 1. Navigation Bar */}
      <header
        className={`sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#E8E5DF] transition-shadow duration-200 ${
          isScrolled ? 'shadow-md shadow-black/5' : ''
        }`}
      >
        <div className="max-w-[1160px] mx-auto px-5 h-[72px] flex items-center justify-between">
          {/* Brand Logo */}
          <a href="#" className="inline-flex items-center gap-3 no-underline text-[#232220] group">
            <div className="w-[54px] h-[54px] flex-shrink-0 flex items-center justify-center relative">
              <img
                src={beeCatMascotImg}
                alt="Mascote Abelhinha Pet Shop"
                className="w-full h-full object-contain filter drop-shadow-[0_4px_8px_rgba(246,184,29,0.3)] transition-transform group-hover:scale-105"
              />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-[1.3rem] font-black text-[#F6B81D] tracking-tight drop-shadow-xs">
                Abelhinha
              </span>
              <span className="text-[0.75rem] font-extrabold uppercase tracking-[0.16em] text-[#378E80]">
                Pet Shop
              </span>
            </div>
          </a>

          {/* Nav Links */}
          <nav aria-label="Navegação principal">
            <ul className="hidden md:flex items-center gap-7 list-none m-0 p-0">
              <li>
                <a href="#servicos" className="text-[#4A4845] font-semibold text-[0.925rem] hover:text-[#8C6200] transition-colors">
                  Serviços
                </a>
              </li>
              <li>
                <a href="#diferenciais" className="text-[#4A4845] font-semibold text-[0.925rem] hover:text-[#8C6200] transition-colors">
                  Diferenciais
                </a>
              </li>
              <li>
                <a href="#agendamento" className="text-[#4A4845] font-semibold text-[0.925rem] hover:text-[#8C6200] transition-colors">
                  Agendar
                </a>
              </li>
              <li>
                <a href="#sobre" className="text-[#4A4845] font-semibold text-[0.925rem] hover:text-[#8C6200] transition-colors">
                  Sobre
                </a>
              </li>
              <li>
                <a href="#avaliacoes" className="text-[#4A4845] font-semibold text-[0.925rem] hover:text-[#8C6200] transition-colors">
                  Avaliações
                </a>
              </li>
              <li>
                <a href="#localizacao" className="text-[#4A4845] font-semibold text-[0.925rem] hover:text-[#8C6200] transition-colors">
                  Localização
                </a>
              </li>
              <li>
                <a href="#faq" className="text-[#4A4845] font-semibold text-[0.925rem] hover:text-[#8C6200] transition-colors">
                  Dúvidas
                </a>
              </li>
              <li>
                <a
                  href="#agendamento"
                  className="inline-flex items-center gap-2 bg-[#F6B81D] hover:bg-[#e5a712] text-[#1F1D1A] px-4 py-2 rounded-full font-bold text-[0.875rem] shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all"
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10z" />
                  </svg>
                  Agendar Horário
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main>
        {/* 2. Hero Section */}
        <section className="bg-gradient-to-b from-white via-[#FFFDF5] to-[#FAF9F6] pt-16 pb-14 relative overflow-hidden">
          <div className="max-w-[1160px] mx-auto px-5 relative z-10">
            <div className="max-w-[860px] mx-auto text-center">
              {/* Mascote Heroic Badge */}
              <div className="inline-block mb-8">
                <div className="inline-flex items-center gap-5 bg-white px-8 py-3.5 rounded-full border-2 border-[#F6D678] shadow-[0_10px_30px_rgba(246,184,29,0.18)] hover:-translate-y-1 hover:shadow-[0_14px_36px_rgba(246,184,29,0.28)] transition-all">
                  <div className="w-[140px] h-[140px] sm:w-[160px] sm:h-[160px] flex items-center justify-center flex-shrink-0">
                    <img
                      src={beeCatMascotImg}
                      alt="Mascote Abelhinha Pet Shop"
                      className="w-full h-full object-contain filter drop-shadow-[0_12px_24px_rgba(246,184,29,0.35)] transition-transform hover:scale-105"
                    />
                  </div>
                  <div className="text-left leading-tight">
                    <span className="text-[1.85rem] sm:text-[2.1rem] font-black text-[#1A1917] tracking-tight block">
                      <span className="text-[#D69700]">Abelhinha</span> Pet Shop
                    </span>
                    <span className="text-[0.875rem] font-extrabold uppercase tracking-[0.12em] text-[#378E80] block mt-1">
                      Banho & Tosa • Vila Sônia
                    </span>
                  </div>
                </div>
              </div>

              {/* Sub-badge */}
              <div className="mb-5">
                <span className="inline-flex items-center gap-2 bg-white border border-[#F1E5C4] px-4 py-1.5 rounded-full text-[0.85rem] font-bold text-[#704C00] shadow-xs">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="#378E80" aria-hidden="true">
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                  </svg>
                  Atendimento individualizado · Vila Sônia, São Paulo
                </span>
              </div>

              {/* Headline */}
              <h1 className="text-3xl sm:text-5xl font-extrabold leading-[1.15] text-[#1A1917] tracking-tight mb-5">
                O cuidado que seu pet merece, com o{' '}
                <span className="relative inline-block whitespace-nowrap">
                  carinho de quem ama
                  <span className="absolute left-0 bottom-[8%] w-full h-[30%] bg-[#F6B81D]/35 -z-10 rounded-sm" />
                </span>
              </h1>

              <p className="text-lg sm:text-xl text-[#4A4845] leading-relaxed max-w-[720px] mx-auto mb-9">
                Banho & Tosa e loja de rações e acessórios na Vila Sônia, com atendimento individualizado — um pet por vez, sem gaiolas.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-11">
                <a
                  href="https://wa.me/5511983523034?text=Ol%C3%A1!%20Vim%20pelo%20site%20do%20Abelhinha%20Pet%20Shop%20e%20gostaria%20de%20agendar%20um%20atendimento."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-[#F6B81D] hover:bg-[#e5a712] text-[#1A1917] font-extrabold text-[1.05rem] px-7 py-3.5 rounded-full shadow-[0_6px_18px_rgba(246,184,29,0.35)] hover:shadow-[0_8px_24px_rgba(246,184,29,0.45)] hover:-translate-y-0.5 transition-all"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M19.05 4.91A9.816 9.816 0 0 0 12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01zm-7.01 15.24c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.19 8.19 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c.02 4.54-3.68 8.23-8.22 8.23zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.44.06-.66.31-.22.25-.86.84-.86 2.05 0 1.21.88 2.38 1.01 2.55.12.17 1.74 2.66 4.21 3.73.59.25 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.07-.1-.23-.17-.48-.29z" />
                  </svg>
                  Agendar atendimento via WhatsApp
                </a>
                <a
                  href="#servicos"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-white hover:bg-[#EDF8F6] text-[#232220] hover:text-[#378E80] font-bold text-[1.05rem] px-6 py-3.5 rounded-full border border-[#E8E5DF] hover:border-[#A3DED4] hover:-translate-y-0.5 transition-all"
                >
                  Conhecer serviços
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M7 13l5 5 5-5M7 6l5 5 5-5" />
                  </svg>
                </a>
              </div>

              {/* Trust Bar */}
              <div className="inline-flex flex-wrap items-center justify-center gap-3 sm:gap-5 bg-white border border-[#ECE7D8] px-6 py-3 rounded-2xl sm:rounded-full shadow-xs text-[0.925rem] font-semibold text-[#4A4845]">
                <div className="inline-flex items-center gap-1.5">
                  <span className="text-[#E29400] font-extrabold inline-flex items-center gap-1">
                    Google 4,9
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="#E29400" aria-hidden="true">
                      <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                    </svg>
                  </span>
                  <span>(90 avaliações)</span>
                </div>
                <div className="w-1 h-1 rounded-full bg-[#C4BFB3] hidden sm:block" />
                <div className="inline-flex items-center gap-1.5">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8C6200" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6L9 17l-5-5" />
                  </svg>
                  <span>Atendimento individualizado</span>
                </div>
                <div className="w-1 h-1 rounded-full bg-[#C4BFB3] hidden sm:block" />
                <div className="inline-flex items-center gap-1.5">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="#8C6200" aria-hidden="true">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                  </svg>
                  <span>Vila Sônia, São Paulo</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 3. Serviços */}
        <section id="servicos" className="py-16 sm:py-20 bg-white">
          <div className="max-w-[1160px] mx-auto px-5">
            <div className="text-center max-w-[680px] mx-auto mb-12">
              <span className="inline-flex items-center gap-2 bg-[#FFF7DB] text-[#7A5400] text-[0.825rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full mb-3 border border-[#F6B81D]/45">
                Nossos Serviços
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#232220] tracking-tight mb-3">
                Cuidado completo e produtos com padrão superior
              </h2>
              <p className="text-[#4A4845] text-base sm:text-lg leading-relaxed">
                Aqui o seu pet é atendido com paciência e respeito ao seu tempo, garantindo uma experiência tranquila e feliz.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-7">
              {/* Card 1: Banho & Tosa */}
              <div className="bg-[#FAF9F6] border border-[#E8E5DF] rounded-2xl p-8 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#57B8A8]/15 hover:border-[#A3DED4] transition-all flex flex-col">
                <div className="w-14 h-14 rounded-2xl bg-[#EDF8F6] border border-[#A3DED4] flex items-center justify-center text-[#378E80] mb-5">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9 6l1 1-1 1M15 6l-1 1 1 1" />
                    <path d="M4 11h16a1 1 0 0 1 1 1v3a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4v-3a1 1 0 0 1 1-1z" />
                    <path d="M7 19v2M17 19v2" />
                    <path d="M12 2v4M10 4h4" />
                  </svg>
                </div>
                <h3 className="text-2xl font-bold text-[#232220] mb-3">Banho & Tosa</h3>
                <p className="text-[#4A4845] leading-relaxed mb-5 flex-grow">
                  Banho completo com produtos que não causam alergia, tosa higiênica e acabamento cuidadoso, com paciência especial para pets medrosos ou agitados.
                </p>
                <div className="flex flex-wrap gap-2 pt-4 border-t border-dashed border-[#E8E5DF]">
                  <span className="text-[0.8rem] font-bold bg-[#F0ECE1] text-[#5A564F] px-3 py-1 rounded-md">Hipoalergênico</span>
                  <span className="text-[0.8rem] font-bold bg-[#F0ECE1] text-[#5A564F] px-3 py-1 rounded-md">Tosa Higiênica</span>
                  <span className="text-[0.8rem] font-bold bg-[#F0ECE1] text-[#5A564F] px-3 py-1 rounded-md">Um por vez</span>
                  <span className="text-[0.8rem] font-bold bg-[#F0ECE1] text-[#5A564F] px-3 py-1 rounded-md">Sem gaiolas</span>
                </div>
              </div>

              {/* Card 2: Loja & Acessórios */}
              <div className="bg-[#FAF9F6] border border-[#E8E5DF] rounded-2xl p-8 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#57B8A8]/15 hover:border-[#A3DED4] transition-all flex flex-col">
                <div className="w-14 h-14 rounded-2xl bg-[#EDF8F6] border border-[#A3DED4] flex items-center justify-center text-[#378E80] mb-5">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" />
                    <line x1="3" y1="6" x2="21" y2="6" />
                    <path d="M16 10a4 4 0 0 1-8 0" />
                  </svg>
                </div>
                <h3 className="text-2xl font-bold text-[#232220] mb-3">Loja & Acessórios</h3>
                <p className="text-[#4A4845] leading-relaxed mb-5 flex-grow">
                  Rações, petiscos, brinquedos, bandanas e enfeites fashion selecionados com carinho para deixar seu amigo saudável, alegre e muito charmoso.
                </p>
                <div className="flex flex-wrap gap-2 pt-4 border-t border-dashed border-[#E8E5DF]">
                  <span className="text-[0.8rem] font-bold bg-[#F0ECE1] text-[#5A564F] px-3 py-1 rounded-md">Rações Selecionadas</span>
                  <span className="text-[0.8rem] font-bold bg-[#F0ECE1] text-[#5A564F] px-3 py-1 rounded-md">Petiscos</span>
                  <span className="text-[0.8rem] font-bold bg-[#F0ECE1] text-[#5A564F] px-3 py-1 rounded-md">Bandanas & Laços</span>
                  <span className="text-[0.8rem] font-bold bg-[#F0ECE1] text-[#5A564F] px-3 py-1 rounded-md">Brinquedos</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Diferenciais */}
        <section id="diferenciais" className="py-16 sm:py-20 bg-[#F4F1E8]">
          <div className="max-w-[1160px] mx-auto px-5">
            <div className="text-center max-w-[680px] mx-auto mb-12">
              <span className="inline-flex items-center gap-2 bg-[#FFF7DB] text-[#7A5400] text-[0.825rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full mb-3 border border-[#F6B81D]/45">
                Por Que o Abelhinha?
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#232220] tracking-tight mb-3">
                Diferenciais pensados no bem-estar do seu pet
              </h2>
              <p className="text-[#4A4845] text-base sm:text-lg leading-relaxed">
                Mais do que estética animal: acolhimento real, segurança e tranquilidade para a sua família.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white border border-[#E8E5DF] rounded-2xl p-6 hover:-translate-y-1 hover:border-[#A3DED4] transition-all">
                <div className="w-11 h-11 rounded-xl bg-[#EDF8F6] text-[#378E80] border border-[#A3DED4] flex items-center justify-center mb-4">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-[#232220] mb-2">Atendimento individualizado</h3>
                <p className="text-[#4A4845] text-sm leading-relaxed">Um cão por vez, sem gaiolas e sem estresse — cada horário tem um único pet.</p>
              </div>

              <div className="bg-white border border-[#E8E5DF] rounded-2xl p-6 hover:-translate-y-1 hover:border-[#A3DED4] transition-all">
                <div className="w-11 h-11 rounded-xl bg-[#EDF8F6] text-[#378E80] border border-[#A3DED4] flex items-center justify-center mb-4">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-[#232220] mb-2">Paciência com todos os pets</h3>
                <p className="text-[#4A4845] text-sm leading-relaxed">Especialistas em cães bravos, medrosos ou idosos; conquistam até os mais difíceis.</p>
              </div>

              <div className="bg-white border border-[#E8E5DF] rounded-2xl p-6 hover:-translate-y-1 hover:border-[#A3DED4] transition-all">
                <div className="w-11 h-11 rounded-xl bg-[#EDF8F6] text-[#378E80] border border-[#A3DED4] flex items-center justify-center mb-4">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-[#232220] mb-2">Produtos que não dão alergia</h3>
                <p className="text-[#4A4845] text-sm leading-relaxed">Banho com produtos de alta qualidade e fragrâncias suaves hipoalergênicas.</p>
              </div>

              <div className="bg-white border border-[#E8E5DF] rounded-2xl p-6 hover:-translate-y-1 hover:border-[#A3DED4] transition-all">
                <div className="w-11 h-11 rounded-xl bg-[#EDF8F6] text-[#378E80] border border-[#A3DED4] flex items-center justify-center mb-4">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-[#232220] mb-2">Pets saem fashion</h3>
                <p className="text-[#4A4845] text-sm leading-relaxed">Bandanas, laços e enfeites que deixam seu pet ainda mais charmoso e vaidoso.</p>
              </div>

              <div className="bg-white border border-[#E8E5DF] rounded-2xl p-6 hover:-translate-y-1 hover:border-[#A3DED4] transition-all">
                <div className="w-11 h-11 rounded-xl bg-[#EDF8F6] text-[#378E80] border border-[#A3DED4] flex items-center justify-center mb-4">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-[#232220] mb-2">Espaço acolhedor</h3>
                <p className="text-[#4A4845] text-sm leading-relaxed">Empresa que acolhe e respeita a comunidade LGBTQ+; espaço seguro para pessoas transgênero.</p>
              </div>

              <div className="bg-white border border-[#E8E5DF] rounded-2xl p-6 hover:-translate-y-1 hover:border-[#A3DED4] transition-all">
                <div className="w-11 h-11 rounded-xl bg-[#EDF8F6] text-[#378E80] border border-[#A3DED4] flex items-center justify-center mb-4">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="5" width="20" height="14" rx="2" />
                    <line x1="2" y1="10" x2="22" y2="10" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-[#232220] mb-2">Conveniência</h3>
                <p className="text-[#4A4845] text-sm leading-relaxed">Estacionamento descoberto gratuito e na rua; aceita cartão de crédito, débito e NFC.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 5. Agendamento Fácil */}
        <section id="agendamento" className="py-16 sm:py-20 bg-white">
          <div className="max-w-[1160px] mx-auto px-5">
            <div className="text-center max-w-[680px] mx-auto mb-12">
              <span className="inline-flex items-center gap-2 bg-[#FFF7DB] text-[#7A5400] text-[0.825rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full mb-3 border border-[#F6B81D]/45">
                Agendamento Fácil
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#232220] tracking-tight mb-3">
                Agende o horário do seu pet
              </h2>
              <p className="text-[#4A4845] text-base sm:text-lg leading-relaxed">
                Escolha as opções abaixo para montar sua mensagem personalizada e abrir direto no nosso WhatsApp.
              </p>
            </div>

            <div className="max-w-[820px] mx-auto bg-white border-2 border-[#F1DC99] rounded-3xl p-6 sm:p-10 shadow-[0_16px_40px_rgba(246,184,29,0.12)]">
              <form onSubmit={(e) => { e.preventDefault(); handleSendWhatsApp(); }}>
                {/* Etapa 1 */}
                <div className="mb-7">
                  <span className="block text-sm font-extrabold text-[#232220] mb-2">Etapa 1 — Tipo do pet:</span>
                  <div className="flex flex-wrap gap-2">
                    {['Cachorro', 'Gato', 'Outro'].map((type) => {
                      const icons: Record<string, string> = { Cachorro: '🐶', Gato: '🐱', Outro: '🐾' };
                      const isSelected = petType === type;
                      return (
                        <button
                          key={type}
                          type="button"
                          onClick={() => setPetType(type)}
                          className={`px-4 py-2 rounded-full font-bold text-sm transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#F6B81D] text-[#1A1917] border-2 border-[#D69700] shadow-sm'
                              : 'bg-[#F7F5EE] border border-[#DFDBD0] text-[#383633] hover:bg-[#EFECE1]'
                          }`}
                        >
                          {icons[type]} {type}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Etapa 2 */}
                <div className="mb-7">
                  <span className="block text-sm font-extrabold text-[#232220] mb-1">Etapa 2 — Serviço desejado:</span>
                  <span className="text-xs text-[#7A766F] block mb-2.5">pode escolher mais de um — ex.: banho + tosa higiênica</span>
                  <div className="flex flex-wrap gap-2">
                    {['Banho & Tosa', 'Somente Banho', 'Tosa Higiênica', 'Hidratação', 'Outro/Personalizado'].map((srv) => {
                      const isSelected = services.includes(srv);
                      return (
                        <button
                          key={srv}
                          type="button"
                          onClick={() => toggleService(srv)}
                          className={`px-4 py-2 rounded-full font-bold text-sm transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#F6B81D] text-[#1A1917] border-2 border-[#D69700] shadow-sm'
                              : 'bg-[#F7F5EE] border border-[#DFDBD0] text-[#383633] hover:bg-[#EFECE1]'
                          }`}
                        >
                          {srv === 'Outro/Personalizado' ? 'Outro / Personalizado' : srv}
                        </button>
                      );
                    })}
                  </div>

                  {isCustomOpen && (
                    <div className="mt-3">
                      <label htmlFor="customInput" className="text-xs text-[#7A766F] block mb-1">
                        Descreva o serviço personalizado:
                      </label>
                      <input
                        id="customInput"
                        type="text"
                        value={customService}
                        onChange={(e) => setCustomService(e.target.value)}
                        placeholder="Ex.: Banho com corte de unhas e hidratação especial"
                        className="w-full px-3.5 py-2 border border-[#E8E5DF] rounded-xl text-sm focus:outline-[#F6B81D] bg-[#FAF9F6]"
                      />
                    </div>
                  )}
                </div>

                {/* Etapa 3 */}
                <div className="mb-7">
                  <span className="block text-sm font-extrabold text-[#232220] mb-2">Etapa 3 — Porte do pet:</span>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { key: 'Pequeno', label: 'Pequeno (até 10kg)' },
                      { key: 'Médio', label: 'Médio (10kg a 25kg)' },
                      { key: 'Grande', label: 'Grande (mais de 25kg)' },
                    ].map((sz) => {
                      const isSelected = petSize === sz.key;
                      return (
                        <button
                          key={sz.key}
                          type="button"
                          onClick={() => setPetSize(sz.key)}
                          className={`px-4 py-2 rounded-full font-bold text-sm transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#F6B81D] text-[#1A1917] border-2 border-[#D69700] shadow-sm'
                              : 'bg-[#F7F5EE] border border-[#DFDBD0] text-[#383633] hover:bg-[#EFECE1]'
                          }`}
                        >
                          {sz.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Etapa 4 */}
                <div className="mb-7">
                  <span className="block text-sm font-extrabold text-[#232220] mb-2">Etapa 4 — Preferência de data e horário:</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <span className="text-xs text-[#7A766F] block mb-2">Dia da semana preferido:</span>
                      <div className="flex flex-wrap gap-2">
                        {['Terça a Sexta', 'Sábado'].map((day) => (
                          <button
                            key={day}
                            type="button"
                            onClick={() => setPrefDay(day)}
                            className={`px-3.5 py-1.5 rounded-full font-bold text-sm transition-all cursor-pointer ${
                              prefDay === day
                                ? 'bg-[#F6B81D] text-[#1A1917] border-2 border-[#D69700]'
                                : 'bg-[#F7F5EE] border border-[#DFDBD0] text-[#383633]'
                            }`}
                          >
                            {day}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <span className="text-xs text-[#7A766F] block mb-2">Período preferido:</span>
                      <div className="flex flex-wrap gap-2">
                        {['Manhã', 'Tarde'].map((period) => (
                          <button
                            key={period}
                            type="button"
                            onClick={() => setPrefPeriod(period)}
                            className={`px-3.5 py-1.5 rounded-full font-bold text-sm transition-all cursor-pointer ${
                              prefPeriod === period
                                ? 'bg-[#F6B81D] text-[#1A1917] border-2 border-[#D69700]'
                                : 'bg-[#F7F5EE] border border-[#DFDBD0] text-[#383633]'
                            }`}
                          >
                            {period}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Prévia */}
                <div className="bg-[#FAF8F2] border border-dashed border-[#E2DAC4] rounded-xl p-4 mb-6 text-sm text-[#55524B] leading-relaxed">
                  <strong className="text-[#232220]">Prévia da mensagem:</strong>
                  <p className="mt-1">{buildBookingMessage()}</p>
                </div>

                {/* Botão Enviar WhatsApp */}
                <button
                  type="submit"
                  disabled={!isFormValid}
                  className={`w-full py-4 rounded-full font-extrabold text-base flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                    isFormValid
                      ? 'bg-[#25D366] hover:bg-[#20BA5A] text-white shadow-[0_6px_18px_rgba(37,211,102,0.35)] hover:shadow-[0_8px_24px_rgba(37,211,102,0.45)] hover:-translate-y-0.5'
                      : 'bg-[#E3E0D8] text-[#8C887E] cursor-not-allowed shadow-none'
                  }`}
                >
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M19.05 4.91A9.816 9.816 0 0 0 12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01zm-7.01 15.24c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.19 8.19 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c.02 4.54-3.68 8.23-8.22 8.23zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.44.06-.66.31-.22.25-.86.84-.86 2.05 0 1.21.88 2.38 1.01 2.55.12.17 1.74 2.66 4.21 3.73.59.25 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.07-.1-.23-.17-.48-.29z" />
                  </svg>
                  Enviar pelo WhatsApp
                </button>
                {!isFormValid && (
                  <div className="text-center text-xs text-[#8C887E] mt-2.5">
                    Selecione o serviço e o porte para continuar
                  </div>
                )}
              </form>
            </div>
          </div>
        </section>

        {/* 6. Sobre Nós */}
        <section id="sobre" className="py-16 sm:py-20 bg-[#FFFDF8]">
          <div className="max-w-[1160px] mx-auto px-5">
            <div className="bg-white border border-[#E8E5DF] rounded-3xl p-8 sm:p-12 grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
              <div>
                <span className="inline-flex items-center gap-2 bg-[#FFF7DB] text-[#7A5400] text-[0.825rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full mb-3 border border-[#F6B81D]/45">
                  Nossa Proposta
                </span>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-[#232220] tracking-tight mb-4">
                  Um espaço pensado para o conforto e a tranquilidade
                </h2>
                <p className="text-[#4A4845] text-base sm:text-lg leading-relaxed mb-3">
                  Atendimento individualizado e acolhedor, um pet por vez, sem gaiolas — cada horário dedicado a um único cão.
                </p>
                <p className="text-[#4A4845] text-base sm:text-lg leading-relaxed">
                  Equipe apaixonada por animais, com paciência e carinho para conquistar até os pets mais desconfiados.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#FAF8F2] border border-[#ECE7D8] p-5 rounded-2xl text-center">
                  <div className="text-3xl font-extrabold text-[#8C6200] leading-none mb-1">1</div>
                  <div className="text-xs font-semibold text-[#5F5C54]">Pet por horário exclusivo</div>
                </div>
                <div className="bg-[#FAF8F2] border border-[#ECE7D8] p-5 rounded-2xl text-center">
                  <div className="text-3xl font-extrabold text-[#8C6200] leading-none mb-1">0</div>
                  <div className="text-xs font-semibold text-[#5F5C54]">Gaiolas ou estresse</div>
                </div>
                <div className="bg-[#FAF8F2] border border-[#ECE7D8] p-5 rounded-2xl text-center">
                  <div className="text-3xl font-extrabold text-[#8C6200] leading-none mb-1">4,9★</div>
                  <div className="text-xs font-semibold text-[#5F5C54]">Nota média no Google</div>
                </div>
                <div className="bg-[#FAF8F2] border border-[#ECE7D8] p-5 rounded-2xl text-center">
                  <div className="text-3xl font-extrabold text-[#8C6200] leading-none mb-1">100%</div>
                  <div className="text-xs font-semibold text-[#5F5C54]">Acolhedor e seguro</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 7. Avaliações (Carrossel) */}
        <section id="avaliacoes" className="py-16 sm:py-20 bg-white">
          <div className="max-w-[1160px] mx-auto px-5">
            <div className="text-center max-w-[680px] mx-auto mb-12">
              <span className="inline-flex items-center gap-2 bg-[#FFF7DB] text-[#7A5400] text-[0.825rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full mb-3 border border-[#F6B81D]/45">
                Depoimentos Reais
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#232220] tracking-tight mb-3">
                O que dizem os tutores da Vila Sônia
              </h2>
              <p className="text-[#4A4845] text-base sm:text-lg leading-relaxed">
                Avaliações autênticas compartilhadas por clientes no Google Maps. Nota geral:{' '}
                <strong>Google 4,9 ★ (90 avaliações)</strong>.
              </p>
            </div>

            <div className="max-w-[900px] mx-auto">
              <div className="overflow-hidden rounded-2xl">
                <div
                  className="flex transition-transform duration-500 ease-in-out"
                  style={{ transform: `translateX(-${currentSlide * 100}%)` }}
                >
                  {REVIEWS_DATA.map((rev, idx) => (
                    <div key={idx} className="min-w-full p-2 box-border">
                      <div className="bg-white border border-[#E8E5DF] rounded-2xl p-8 sm:p-10 shadow-sm flex flex-col justify-between min-h-[220px]">
                        <div>
                          <div className="flex gap-1 text-[#F6B81D] mb-4">
                            {[...Array(5)].map((_, i) => (
                              <svg key={i} width="18" height="18" viewBox="0 0 24 24" fill="#F6B81D" aria-hidden="true">
                                <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                              </svg>
                            ))}
                          </div>
                          <p className="text-lg text-[#2F2E2A] italic leading-relaxed mb-6">
                            "{rev.text}"
                          </p>
                        </div>
                        <div className="flex items-center justify-between border-t border-[#F1EFE8] pt-4 mt-auto">
                          <span className="font-extrabold text-[#1F1D1A] text-sm sm:text-base">{rev.name}</span>
                          <span className="text-xs font-semibold text-[#7E7A71] inline-flex items-center gap-1.5">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="#EA4335" aria-hidden="true">
                              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                            </svg>
                            Fonte: Google Maps
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Controles */}
              <div className="flex items-center justify-center gap-4 mt-6">
                <button
                  type="button"
                  onClick={() => setCurrentSlide((prev) => (prev - 1 + REVIEWS_DATA.length) % REVIEWS_DATA.length)}
                  className="w-10 h-10 rounded-full bg-white border border-[#E8E5DF] text-[#232220] flex items-center justify-center hover:bg-[#FFF7DB] hover:border-[#E0C77A] transition-colors cursor-pointer"
                  aria-label="Avaliação anterior"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="15 18 9 12 15 6" />
                  </svg>
                </button>

                <div className="flex gap-2">
                  {REVIEWS_DATA.map((_, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setCurrentSlide(idx)}
                      className={`h-2 rounded-full transition-all cursor-pointer ${
                        idx === currentSlide ? 'w-6 bg-[#F6B81D]' : 'w-2 bg-[#DDD9CF]'
                      }`}
                      aria-label={`Ir para avaliação ${idx + 1}`}
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => setCurrentSlide((prev) => (prev + 1) % REVIEWS_DATA.length)}
                  className="w-10 h-10 rounded-full bg-white border border-[#E8E5DF] text-[#232220] flex items-center justify-center hover:bg-[#FFF7DB] hover:border-[#E0C77A] transition-colors cursor-pointer"
                  aria-label="Próxima avaliação"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="9 18 15 12 9 6" />
                  </svg>
                </button>
              </div>

              <div className="text-center mt-7">
                <a
                  href="https://www.google.com/maps/search/?api=1&query=Pet+Shop+Abelhinha+Vila+S%C3%B4nia"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-white border border-[#E8E5DF] hover:bg-[#F9F7F1] text-[#1F1D1A] font-bold text-sm px-5 py-2.5 rounded-full shadow-xs hover:-translate-y-0.5 transition-all"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="#EA4335" aria-hidden="true">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                  </svg>
                  Ver todas as avaliações no Google (90+)
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* 8. Localização & Mapa */}
        <section id="localizacao" className="py-16 sm:py-20 bg-[#F4F1E8]">
          <div className="max-w-[1160px] mx-auto px-5">
            <div className="text-center max-w-[680px] mx-auto mb-12">
              <span className="inline-flex items-center gap-2 bg-[#FFF7DB] text-[#7A5400] text-[0.825rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full mb-3 border border-[#F6B81D]/45">
                Onde Estamos
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#232220] tracking-tight mb-3">
                Fácil acesso na Vila Sônia
              </h2>
              <p className="text-[#4A4845] text-base sm:text-lg leading-relaxed">
                Venha nos visitar ou traga seu pet com toda a praticidade de estacionamento no local e na rua.
              </p>
            </div>

            <div className="bg-white border border-[#E8E5DF] rounded-3xl overflow-hidden shadow-sm grid grid-cols-1 lg:grid-cols-2">
              <div className="p-8 sm:p-12 flex flex-col justify-center">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-9 h-9 rounded-xl bg-[#FFF8E1] text-[#8C6200] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider font-extrabold text-[#8A857B] mb-1">Endereço</div>
                    <div className="text-base text-[#2F2E2A] font-semibold leading-snug">
                      R. Luís Carlos Ventura, 54<br />
                      Vila Sônia, São Paulo/SP — CEP 05628-020
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4 mb-6">
                  <div className="w-9 h-9 rounded-xl bg-[#FFF8E1] text-[#8C6200] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider font-extrabold text-[#8A857B] mb-1">Horário de Funcionamento</div>
                    <div className="text-base text-[#2F2E2A] font-semibold leading-snug">
                      Terça a Sexta: 09:00 – 17:00<br />
                      Sábado: 09:00 – 15:00<br />
                      <span className="text-[#8C887E] font-medium text-sm">Domingo e Segunda: Fechado</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4 mb-6">
                  <div className="w-9 h-9 rounded-xl bg-[#FFF8E1] text-[#8C6200] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider font-extrabold text-[#8A857B] mb-1">Pagamento & Facilidades</div>
                    <div className="text-base text-[#2F2E2A] font-semibold leading-snug">
                      Cartão de crédito, débito e aproximação (NFC).<br />
                      Estacionamento descoberto gratuito e gratuito na rua.
                    </div>
                  </div>
                </div>

                <div className="mt-2">
                  <a
                    href="https://www.google.com/maps/search/?api=1&query=R.+Lu%C3%ADs+Carlos+Ventura,+54+-+Vila+S%C3%B4nia,+S%C3%A3o+Paulo+-+SP,+05628-020"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-[#F6B81D] hover:bg-[#e5a712] text-[#1A1917] font-bold text-sm px-6 py-3 rounded-full shadow-xs hover:-translate-y-0.5 transition-all"
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polygon points="3 11 22 2 13 21 11 13 3 11" />
                    </svg>
                    Como Chegar (Google Maps)
                  </a>
                </div>
              </div>

              <div className="min-h-[320px] lg:min-h-[420px] bg-[#E8E5DF]">
                <iframe
                  src="https://www.google.com/maps?q=R.+Lu%C3%ADs+Carlos+Ventura,+54+-+Vila+Sonia,+S%C3%A3o+Paulo+-+SP,+05628-020&output=embed"
                  className="w-full h-full min-h-[320px] border-0 block"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Mapa de localização do Pet Shop Abelhinha na Vila Sônia"
                />
              </div>
            </div>
          </div>
        </section>

        {/* 9. FAQ */}
        <section id="faq" className="py-16 sm:py-20 bg-white">
          <div className="max-w-[1160px] mx-auto px-5">
            <div className="text-center max-w-[680px] mx-auto mb-12">
              <span className="inline-flex items-center gap-2 bg-[#FFF7DB] text-[#7A5400] text-[0.825rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full mb-3 border border-[#F6B81D]/45">
                Tire Suas Dúvidas
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#232220] tracking-tight mb-3">
                Perguntas Frequentes
              </h2>
              <p className="text-[#4A4845] text-base sm:text-lg leading-relaxed">
                Informações diretas e transparentes sobre o nosso atendimento.
              </p>
            </div>

            <div className="max-w-[780px] mx-auto flex flex-col gap-3.5">
              {[
                { q: 'Onde fica o Abelhinha?', a: 'R. Luís Carlos Ventura, 54 — Vila Sônia, São Paulo/SP (CEP 05628-020).' },
                { q: 'Quais serviços vocês oferecem?', a: 'Banho & Tosa com atendimento individualizado e loja de rações, petiscos e acessórios.' },
                { q: 'Meu cão é medroso ou bravo, vocês aceitam?', a: 'Sim! Somos especializados em pets difíceis — cada horário é dedicado a um único cão, sem gaiolas e com muita paciência.' },
                { q: 'Como agendo?', a: 'Pelo botão de agendamento do site, que abre o WhatsApp (11) 98352-3034 com os dados já preenchidos.' },
                { q: 'Qual o horário?', a: 'Terça a Sexta 09h–17h, Sábado 09h–15h, domingo e segunda fechado.' },
                { q: 'Quais formas de pagamento?', a: 'Cartão de crédito, débito e aproximação (NFC).' },
              ].map((item, i) => (
                <details key={i} className="group bg-white border border-[#E8E5DF] open:border-[#E2CA78] rounded-xl overflow-hidden transition-colors">
                  <summary className="flex items-center justify-between p-5 text-base font-bold text-[#232220] cursor-pointer select-none list-none">
                    <span>{item.q}</span>
                    <svg className="w-5 h-5 text-[#8C6200] transition-transform duration-200 group-open:rotate-180" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </summary>
                  <div className="px-5 pb-5 text-sm text-[#4A4845] leading-relaxed border-t border-[#FAF8F2] pt-2">
                    {item.a}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* 10. Final CTA */}
        <section className="bg-gradient-to-br from-[#FFF6D6] to-[#FFE99B] border-y border-[#F1DE99] py-16 text-center">
          <div className="max-w-[680px] mx-auto px-5">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1A1917] tracking-tight mb-4">
              Agende o banho & tosa do seu pet
            </h2>
            <p className="text-lg text-[#575141] leading-relaxed mb-8">
              Garanta um horário exclusivo com todo o cuidado, carinho e respeito que o seu melhor amigo merece.
            </p>
            <a
              href="https://wa.me/5511983523034?text=Ol%C3%A1!%20Vim%20pelo%20site%20do%20Abelhinha%20Pet%20Shop%20e%20gostaria%20de%20agendar%20um%20atendimento."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 bg-[#1F1D1A] hover:bg-black text-white font-extrabold text-lg px-8 py-4 rounded-full shadow-lg hover:-translate-y-0.5 transition-all"
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="#25D366" aria-hidden="true">
                <path d="M19.05 4.91A9.816 9.816 0 0 0 12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01zm-7.01 15.24c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.19 8.19 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c.02 4.54-3.68 8.23-8.22 8.23zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.44.06-.66.31-.22.25-.86.84-.86 2.05 0 1.21.88 2.38 1.01 2.55.12.17 1.74 2.66 4.21 3.73.59.25 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.07-.1-.23-.17-.48-.29z" />
              </svg>
              Falar pelo WhatsApp (11) 98352-3034
            </a>
          </div>
        </section>
      </main>

      {/* 11. Rodapé */}
      <footer className="bg-[#1F1D1B] text-[#E8E5DF] pt-14 pb-10 text-sm">
        <div className="max-w-[1160px] mx-auto px-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
            {/* Col 1 */}
            <div>
              <div className="inline-flex items-center gap-3 mb-4">
                <div className="w-12 h-12 flex items-center justify-center">
                  <img
                    src={beeCatMascotImg}
                    alt="Mascote Abelhinha Pet Shop"
                    className="w-full h-full object-contain filter drop-shadow-[0_2px_6px_rgba(246,184,29,0.3)]"
                  />
                </div>
                <div className="flex flex-col leading-tight">
                  <span className="text-xl font-black text-[#F6B81D]">Abelhinha</span>
                  <span className="text-xs font-extrabold uppercase tracking-wider text-[#A3DED4]">Pet Shop</span>
                </div>
              </div>
              <p className="text-[#AAA69E] leading-relaxed">
                O cuidado que seu pet merece, com o carinho de quem ama. Banho & tosa individualizado e loja na Vila Sônia.
              </p>
            </div>

            {/* Col 2 */}
            <div>
              <h4 className="text-white font-bold text-base mb-4">Endereço e Horários</h4>
              <p className="text-[#AAA69E] leading-relaxed">
                R. Luís Carlos Ventura, 54<br />
                Vila Sônia — São Paulo/SP<br />
                CEP 05628-020
              </p>
              <p className="text-[#AAA69E] leading-relaxed mt-2">
                Terça a Sexta: 09h às 17h<br />
                Sábado: 09h às 15h<br />
                Domingo e Segunda: Fechado
              </p>
            </div>

            {/* Col 3 */}
            <div>
              <h4 className="text-white font-bold text-base mb-4">Canais Oficiais</h4>
              <p className="text-[#AAA69E] leading-relaxed mb-2">
                WhatsApp:{' '}
                <a href="https://wa.me/5511983523034" target="_blank" rel="noopener noreferrer" className="text-[#F6B81D] hover:underline">
                  (11) 98352-3034
                </a>
              </p>
              <p className="text-[#AAA69E] leading-relaxed">
                Instagram:{' '}
                <a href="https://www.instagram.com/petshopabelhinha/" target="_blank" rel="noopener noreferrer" className="text-[#F6B81D] hover:underline">
                  @petshopabelhinha
                </a>
              </p>
            </div>
          </div>

          <div className="border-t border-[#33312D] pt-7 flex flex-wrap items-center justify-between gap-4 text-xs text-[#8C8880]">
            <div>© {new Date().getFullYear()} Abelhinha Pet Shop. Todos os direitos reservados.</div>
            <div className="inline-flex items-center gap-1.5 bg-[#2E2B27] text-[#E2DCB8] border border-[#454037] px-3 py-1 rounded-full text-xs font-semibold">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#F6B81D" aria-hidden="true">
                <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z" />
              </svg>
              Site oficial do Abelhinha Pet Shop
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Buttons */}
      <div className="fixed right-5 bottom-5 flex flex-col gap-3 z-50">
        {/* Instagram */}
        <a
          href="https://www.instagram.com/petshopabelhinha/"
          target="_blank"
          rel="noopener noreferrer"
          className="w-[54px] h-[54px] rounded-full flex items-center justify-center text-white shadow-lg hover:scale-108 hover:-translate-y-1 transition-all bg-[radial-gradient(circle_at_30%_107%,#fdf497_0%,#fdf497_5%,#fd5949_45%,#d6249f_60%,#285AEB_90%)]"
          aria-label="Acessar Instagram @petshopabelhinha"
        >
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
          </svg>
        </a>

        {/* WhatsApp */}
        <a
          href="https://wa.me/5511983523034"
          target="_blank"
          rel="noopener noreferrer"
          className="w-[54px] h-[54px] rounded-full flex items-center justify-center text-white bg-[#25D366] shadow-lg hover:scale-108 hover:-translate-y-1 transition-all"
          aria-label="Falar no WhatsApp oficial"
        >
          <svg width="30" height="30" viewBox="0 0 24 24" fill="#FFFFFF" aria-hidden="true">
            <path d="M19.05 4.91A9.816 9.816 0 0 0 12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01zm-7.01 15.24c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.19 8.19 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c.02 4.54-3.68 8.23-8.22 8.23zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.44.06-.66.31-.22.25-.86.84-.86 2.05 0 1.21.88 2.38 1.01 2.55.12.17 1.74 2.66 4.21 3.73.59.25 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.07-.1-.23-.17-.48-.29z" />
          </svg>
        </a>
      </div>

      {/* Back to top */}
      <button
        type="button"
        onClick={scrollToTop}
        className={`fixed left-5 bottom-5 w-[46px] h-[46px] rounded-full bg-white border border-[#E8E5DF] text-[#232220] flex items-center justify-center shadow-md cursor-pointer z-50 transition-all ${
          showBackToTop ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-3 pointer-events-none'
        } hover:bg-[#FFF7DB] hover:border-[#E0C77A]`}
        aria-label="Voltar ao início da página"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="18 15 12 9 6 15" />
        </svg>
      </button>
    </div>
  );
}
