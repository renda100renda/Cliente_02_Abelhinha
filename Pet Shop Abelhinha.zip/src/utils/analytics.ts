// Safe Analytics Dispatcher for GA4, GTM, Meta Pixel & Local CRO Tracking

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
    dataLayer?: unknown[];
    fbq?: (...args: unknown[]) => void;
  }
}

export function trackConversionEvent(eventName: string, params?: Record<string, unknown>) {
  try {
    // 1. Google Analytics (gtag)
    if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
      window.gtag('event', eventName, params);
    }

    // 2. Google Tag Manager (dataLayer)
    if (typeof window !== 'undefined' && Array.isArray(window.dataLayer)) {
      window.dataLayer.push({
        event: eventName,
        ...params,
        timestamp: new Date().toISOString(),
      });
    }

    // 3. Meta Pixel (fbq)
    if (typeof window !== 'undefined' && typeof window.fbq === 'function') {
      window.fbq('trackCustom', eventName, params);
      if (eventName.includes('whatsapp') || eventName.includes('lead') || eventName.includes('schedule')) {
        window.fbq('track', 'Lead', params);
      }
    }

    // Console logging for verification
    if (process.env.NODE_ENV !== 'production') {
      console.log(`[CRO Event Tracked]: ${eventName}`, params);
    }
  } catch (err) {
    console.warn('Analytics tracking error:', err);
  }
}

export function openWhatsAppWithTracking(url: string, source: string, unit: string = 'Vila Sônia / Morumbi') {
  trackConversionEvent('whatsapp_click', {
    source,
    unit,
    timestamp: new Date().toISOString()
  });

  // Open WhatsApp in new tab
  window.open(url, '_blank', 'noopener,noreferrer');
}
