export interface Review {
  id: string;
  author: string;
  role?: string;
  avatarUrl?: string;
  rating: number;
  timeAgo: string;
  text: string;
  petName?: string;
  breed?: string;
  unit: 'Morumbi' | 'Vila Sônia';
  ownerResponse?: string;
}

export interface UnitInfo {
  id: 'morumbi' | 'vila-sonia';
  name: string;
  fullName: string;
  rating: number;
  reviewCount: number;
  address: string;
  neighborhood: string;
  cep: string;
  phone: string;
  phoneRaw: string;
  whatsappLink: string;
  googleMapsUrl: string;
  hours: string;
  highlights: string[];
}

export interface ServiceItem {
  id: string;
  name: string;
  tagline: string;
  description: string;
  deliverables: string[];
  recommendedFor: string;
  iconName: string;
}
