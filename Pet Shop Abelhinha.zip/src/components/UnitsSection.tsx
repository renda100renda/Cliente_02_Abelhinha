import React from 'react';
import { MapPin, Phone, Clock, Star, MessageCircle, Navigation, ShieldCheck, Heart } from 'lucide-react';
import { UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const UnitsSection: React.FC = () => {
  const unitsList = Object.values(UNITS);

  const handleUnitWhatsApp = (phoneRaw: string, name: string) => {
    const url = `https://wa.me/${phoneRaw}?text=Ol%C3%A1!%20Vim%20pelo%20site%20da%20AUpetMIAU%20e%20gostaria%20de%20tirar%20uma%20d%C3%BAvida%20sobre%20a%20unidade%20${encodeURIComponent(name)}!`;
    openWhatsAppWithTracking(url, 'unit_card_direct', name);
  };

  return (
    <section id="unidades" className="py-20 lg:py-28 bg-[#0D1217] relative border-t border-stone-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3">
            <MapPin className="w-3.5 h-3.5" />
            <span>Nossos Espaços Físicos</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            Duas Unidades Completas na Zona Sul de São Paulo
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            Visite pessoalmente ou solicite nosso Táxi Dog para buscar seu pet com segurança no seu endereço.
          </p>
        </div>

        {/* Units Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {unitsList.map((unit) => (
            <div
              key={unit.id}
              className="p-7 sm:p-8 rounded-2xl bg-[#11171E] border border-stone-800 hover:border-[#E0A96D]/50 transition-all flex flex-col justify-between shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#E0A96D]/5 rounded-bl-full pointer-events-none" />

              <div>
                {/* Unit Header */}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#E0A96D] block mb-1">
                      {unit.id === 'morumbi' ? 'Unidade I' : 'Unidade II'}
                    </span>
                    <h3 className="text-2xl font-bold text-white font-serif-luxury">
                      {unit.fullName}
                    </h3>
                  </div>

                  <div className="text-right">
                    <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/30 text-xs font-bold">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>{unit.rating} ★</span>
                    </div>
                    <p className="text-[10px] text-stone-400 mt-1">({unit.reviewCount} avaliações)</p>
                  </div>
                </div>

                {/* Details List */}
                <div className="space-y-3.5 text-xs text-stone-300 my-6">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-[#E0A96D] shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-stone-200">{unit.address}</p>
                      <p className="text-stone-400">{unit.neighborhood} · CEP {unit.cep}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-[#E0A96D] shrink-0" />
                    <div>
                      <span className="font-semibold text-stone-200">WhatsApp / Tel: </span>
                      <span className="text-stone-300 font-mono">{unit.phone}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div>
                      <span className="font-semibold text-stone-200">Funcionamento: </span>
                      <span className="text-stone-300">{unit.hours}</span>
                    </div>
                  </div>
                </div>

                {/* Highlights tags */}
                <div className="flex flex-wrap gap-2 pt-2 mb-6">
                  {unit.highlights.map((hl, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-md bg-[#16212C] text-stone-300 text-[11px] border border-stone-800"
                    >
                      ✓ {hl}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-4 border-t border-stone-800">
                <a
                  href={unit.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-3 px-3.5 rounded-xl bg-[#17212C] hover:bg-[#1E2B3A] text-stone-200 text-xs font-semibold flex items-center justify-center gap-1.5 border border-stone-700 transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5 text-[#E0A96D]" />
                  <span>Ver no Maps</span>
                </a>

                <button
                  type="button"
                  onClick={() => handleUnitWhatsApp(unit.phoneRaw, unit.name)}
                  className="py-3 px-3.5 rounded-xl bg-[#E0A96D] hover:bg-[#F0B87C] text-stone-950 text-xs font-bold flex items-center justify-center gap-1.5 shadow-md transition-transform hover:scale-105 cursor-pointer"
                >
                  <MessageCircle className="w-3.5 h-3.5 fill-current" />
                  <span>WhatsApp Unidade</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Community & Safety Banner */}
        <div className="mt-12 text-center text-xs text-stone-400 max-w-xl mx-auto flex items-center justify-center gap-4">
          <span className="flex items-center gap-1 text-stone-300">
            <Heart className="w-3.5 h-3.5 text-rose-400" />
            Empresa que acolhe a comunidade LGBTQ+
          </span>
          <span>•</span>
          <span className="flex items-center gap-1 text-stone-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Empresa de Empreendedoras
          </span>
        </div>

      </div>
    </section>
  );
};
