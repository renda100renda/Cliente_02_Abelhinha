import React, { useState } from 'react';
import { MessageCircle, X, Star, MapPin, Sparkles } from 'lucide-react';
import { UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const FloatingWhatsApp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [dismissedNotification, setDismissedNotification] = useState(false);

  const units = Object.values(UNITS);

  const handleSelectUnit = (unit: typeof units[0]) => {
    const text = encodeURIComponent(
      `Olá, AUpetMIAU (${unit.name})! 🐾\nVi o site oficial e gostaria de agendar um horário de Banho & SPA para meu pet. Como funciona a disponibilidade desta semana?`
    );
    openWhatsAppWithTracking(`https://wa.me/${unit.phoneRaw}?text=${text}`, 'floating_whatsapp_widget', unit.name);
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Contextual Popover Card */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-88 rounded-2xl bg-[#121820] border border-stone-700 shadow-2xl p-5 animate-in fade-in slide-in-from-bottom-5">
          <div className="flex items-center justify-between pb-3 border-b border-stone-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <MessageCircle className="w-4 h-4 fill-current" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white leading-tight">Atendimento AUpetMIAU</h4>
                <p className="text-[10px] text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Equipe online no WhatsApp
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-stone-400 hover:text-white rounded-md"
              aria-label="Fechar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-stone-300 my-3 leading-relaxed">
            Selecione qual unidade da AUpetMIAU está mais próxima de você para falar direto no WhatsApp:
          </p>

          <div className="space-y-2.5">
            {units.map((unit) => (
              <button
                key={unit.id}
                onClick={() => handleSelectUnit(unit)}
                className="w-full p-3 rounded-xl bg-[#17202B] hover:bg-[#1E2B3A] border border-stone-800 hover:border-[#E0A96D]/50 text-left transition-all flex items-center justify-between group cursor-pointer"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white group-hover:text-[#E0A96D] transition-colors">
                      {unit.fullName}
                    </span>
                    <span className="text-[10px] text-amber-400 font-bold">
                      {unit.rating} ★
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-400 mt-0.5 truncate max-w-[200px]">
                    {unit.address}
                  </p>
                </div>
                <div className="p-1.5 rounded-lg bg-[#E0A96D]/10 text-[#E0A96D] group-hover:bg-[#E0A96D] group-hover:text-stone-950 transition-colors">
                  <MessageCircle className="w-3.5 h-3.5 fill-current" />
                </div>
              </button>
            ))}
          </div>

          <div className="mt-3 pt-3 border-t border-stone-800 text-center text-[10px] text-stone-400 flex items-center justify-center gap-1">
            <Sparkles className="w-3 h-3 text-[#E0A96D]" />
            <span>Resposta rápida com fotos do pet inclusas</span>
          </div>
        </div>
      )}

      {/* Preview Tooltip Bubble if not dismissed */}
      {!isOpen && !dismissedNotification && (
        <div
          onClick={() => setIsOpen(true)}
          className="mb-2.5 px-3 py-1.5 rounded-xl bg-[#11171E] border border-[#E0A96D]/30 text-stone-200 text-xs shadow-xl flex items-center gap-2 cursor-pointer hover:border-[#E0A96D] transition-all max-w-[220px]"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-[11px] font-medium leading-tight">Dúvidas ou agendamento? Fale no WhatsApp</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setDismissedNotification(true);
            }}
            className="text-stone-500 hover:text-stone-300 ml-1"
          >
            ×
          </button>
        </div>
      )}

      {/* Main Floating Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-4 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white shadow-[0_8px_25px_rgba(16,185,129,0.35)] transition-all hover:scale-110 active:scale-95 cursor-pointer flex items-center justify-center group"
        aria-label="Falar com especialista pelo WhatsApp"
      >
        <MessageCircle className="w-6 h-6 fill-current" />
        
        {/* Unread Ping Badge */}
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-4 w-4 bg-[#E0A96D] text-[9px] font-black text-stone-950 items-center justify-center">
            1
          </span>
        </span>
      </button>

    </div>
  );
};
