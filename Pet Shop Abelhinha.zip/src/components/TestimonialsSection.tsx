import React, { useState } from 'react';
import { Star, MessageSquare, MapPin, CheckCircle2, ShieldCheck, Heart } from 'lucide-react';
import { REVIEWS, UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const TestimonialsSection: React.FC = () => {
  const [filterUnit, setFilterUnit] = useState<'all' | 'Vila Sônia' | 'Morumbi'>('all');

  const filteredReviews =
    filterUnit === 'all'
      ? REVIEWS
      : REVIEWS.filter((r) => r.unit === filterUnit);

  const handleCta = () => {
    const unit = UNITS['vila-sonia'];
    openWhatsAppWithTracking(unit.whatsappLink, 'testimonials_cta', unit.name);
  };

  return (
    <section id="depoimentos" className="py-20 lg:py-28 bg-[#0A0E12] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold tracking-wider uppercase mb-3">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span>Avaliações Reais no Google Maps</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            A Opinião de Quem Ama Seu Pet e Exige o Melhor
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            Histórias reais de tutores do Morumbi e Vila Sônia que confiaram seus cães e gatos aos nossos cuidados.
          </p>

          {/* Unit Filter Tabs */}
          <div className="mt-6 inline-flex p-1 rounded-xl bg-[#11171E] border border-stone-800 text-xs">
            <button
              onClick={() => setFilterUnit('all')}
              className={`px-4 py-2 rounded-lg transition-all ${
                filterUnit === 'all'
                  ? 'bg-[#E0A96D] text-stone-950 font-bold'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              Todas as Avaliações (129+)
            </button>
            <button
              onClick={() => setFilterUnit('Vila Sônia')}
              className={`px-4 py-2 rounded-lg transition-all ${
                filterUnit === 'Vila Sônia'
                  ? 'bg-[#E0A96D] text-stone-950 font-bold'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              Vila Sônia (5.0 ★)
            </button>
            <button
              onClick={() => setFilterUnit('Morumbi')}
              className={`px-4 py-2 rounded-lg transition-all ${
                filterUnit === 'Morumbi'
                  ? 'bg-[#E0A96D] text-stone-950 font-bold'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              Morumbi (4.8 ★)
            </button>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredReviews.map((rev) => (
            <div
              key={rev.id}
              className="p-6 sm:p-7 rounded-2xl bg-[#11171E] border border-stone-800 hover:border-[#E0A96D]/30 transition-all flex flex-col justify-between shadow-xl"
            >
              <div>
                {/* Author Bar */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#E0A96D]/30 to-stone-800 text-[#E0A96D] font-bold text-sm flex items-center justify-center border border-[#E0A96D]/30">
                      {rev.author.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                        {rev.author}
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" title="Verificado no Google" />
                      </h3>
                      <p className="text-[11px] text-stone-400">{rev.role}</p>
                    </div>
                  </div>

                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#16212B] text-stone-300 border border-stone-800">
                    {rev.unit}
                  </span>
                </div>

                {/* Stars */}
                <div className="flex items-center gap-1 text-amber-400 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                  <span className="text-xs text-stone-400 ml-1.5">{rev.timeAgo}</span>
                </div>

                {/* Review Text */}
                <p className="text-stone-300 text-sm leading-relaxed italic">
                  &ldquo;{rev.text}&rdquo;
                </p>

                {/* Specific pet highlighted if present */}
                {rev.petName && (
                  <div className="mt-4 inline-flex items-center gap-1.5 text-xs text-[#E0A96D] bg-[#E0A96D]/10 px-2.5 py-1 rounded-md">
                    <span>🐾 Pet: {rev.petName} ({rev.breed || 'Cãozinho'})</span>
                  </div>
                )}
              </div>

              {/* Owner Friendly Response if present */}
              {rev.ownerResponse && (
                <div className="mt-5 pt-3 border-t border-stone-800/80 text-[11px] text-stone-400 bg-[#0D1217] p-2.5 rounded-lg">
                  <span className="font-semibold text-stone-300">Resposta da AUpetMIAU: </span>
                  <span>{rev.ownerResponse}</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Direct Action after social proof */}
        <div className="mt-14 p-8 rounded-2xl bg-[#121820] border border-[#E0A96D]/30 max-w-3xl mx-auto text-center flex flex-col sm:flex-row items-center justify-between gap-6 glow-gold-subtle">
          <div className="text-left">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Heart className="w-5 h-5 text-rose-400" />
              Seu pet merece esse mesmo carinho
            </h3>
            <p className="text-xs text-stone-400 mt-1">
              Agende agora e comprove a diferença no primeiro banho.
            </p>
          </div>

          <button
            type="button"
            onClick={handleCta}
            className="py-3 px-6 rounded-xl bg-[#E0A96D] hover:bg-[#F0B87C] text-stone-950 font-bold text-xs uppercase tracking-wider whitespace-nowrap shadow-lg transition-transform hover:scale-105 cursor-pointer"
          >
            Reservar Horário no WhatsApp
          </button>
        </div>

      </div>
    </section>
  );
};
