import React from 'react';
import { MessageCircle, Heart, Car, Star, ArrowRight, ShieldCheck, Award } from 'lucide-react';
import { MascotEffectStage } from './MascotEffectStage';
import { UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const Hero: React.FC = () => {
  const defaultUnit = UNITS['morumbi'];

  const handleHeroWhatsApp = () => {
    openWhatsAppWithTracking(defaultUnit.whatsappLink, 'hero_primary_cta', defaultUnit.name);
  };

  return (
    <section className="relative min-h-[94vh] flex items-center pt-28 pb-16 lg:pt-32 lg:pb-20 overflow-hidden bg-gradient-to-b from-[#0C1117] via-[#0E141B] to-[#0A0E13]">
      {/* Warm Ambient Atmosphere & Subtle Lighting */}
      <div className="absolute top-10 right-1/4 w-[550px] h-[550px] bg-[#E0A96D]/12 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[450px] h-[450px] bg-emerald-500/8 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/3 w-[300px] h-[300px] bg-rose-500/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Elegant Radial Dot Matrix */}
      <div
        className="absolute inset-0 opacity-[0.035] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#E0A96D 1.2px, transparent 1.2px)`,
          backgroundSize: '28px 28px'
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Value Proposition & High Conversion Trigger */}
          <div className="lg:col-span-7 text-left space-y-6">
            
            {/* Trust Badges Bar */}
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#17202B] border border-[#E0A96D]/30 text-xs shadow-sm">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                </span>
                <span className="font-semibold text-[#E0A96D]">AUpetMIAU Morumbi & Vila Sônia</span>
                <span className="text-stone-500">•</span>
                <span className="text-stone-300 font-medium">Boutique & SPA</span>
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-300 text-xs font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>100% Livre de Gaiolas</span>
              </div>
            </div>

            {/* Headline as requested: Seu Pet Merece o Melhor: Cuidado Premium na Vila Sônia & Morumbi */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif-luxury font-extrabold text-stone-100 tracking-tight leading-[1.12]">
              Seu Pet Merece o Melhor:{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FDE8D0] via-[#E0A96D] to-[#CCA067]">
                Cuidado Premium na Vila Sônia & Morumbi
              </span>
            </h1>

            {/* Subheadline highlighting Banho, Tosa, Táxi Dog, Carinho e Qualidade */}
            <p className="text-base sm:text-lg text-stone-300 max-w-2xl leading-relaxed font-normal">
              Serviços exclusivos de <strong className="text-stone-100 font-semibold">Banho terapêutico</strong>, <strong className="text-stone-100 font-semibold">Tosa na tesoura especializada</strong> e <strong className="text-stone-100 font-semibold">Táxi Dog climatizado</strong>. Aqui seu pet é tratado como membro da família: com respeito ao seu ritmo, cosmética hipoalergênica nobre e muito carinho pela nossa equipe.
            </p>

            {/* Primary Conversion Zone */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                type="button"
                onClick={handleHeroWhatsApp}
                className="py-4 px-8 rounded-xl bg-gradient-to-r from-[#E0A96D] via-[#D89F62] to-[#B37F47] hover:from-[#F0B87C] hover:to-[#DBAE76] text-stone-950 font-bold text-base flex items-center justify-center gap-3 shadow-[0_10px_30px_rgba(224,169,109,0.3)] transition-all hover:scale-105 active:scale-95 cursor-pointer glow-gold-subtle"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>Agende o Banho do Seu Pet</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="#carinho-em-acao"
                className="py-4 px-6 rounded-xl bg-[#151D27] hover:bg-[#1B2633] border border-stone-800 hover:border-[#E0A96D]/40 text-stone-200 hover:text-white font-semibold text-sm flex items-center justify-center gap-2 transition-all shadow-sm"
              >
                <Heart className="w-4 h-4 text-rose-400" />
                <span>Ver o Carinho em Ação</span>
              </a>
            </div>

            {/* Micro Social Proof & Mandatory Verification Seals */}
            <div className="pt-5 border-t border-stone-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              {/* Review score */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>4.8 estrelas de 43 avaliações</span>
                    <span className="text-stone-400 font-normal">(e 5.0 na Vila Sônia)</span>
                  </div>
                  <p className="text-[11px] text-stone-400">
                    Avaliações públicas verificadas no Google Maps
                  </p>
                </div>
              </div>

              {/* Official Seals as requested */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#141B24] border border-stone-800 text-[11px] text-stone-300 font-medium">
                  <Award className="w-3.5 h-3.5 text-[#E0A96D]" />
                  <span>Empreendedoras</span>
                </span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#141B24] border border-stone-800 text-[11px] text-stone-300 font-medium">
                  <Heart className="w-3.5 h-3.5 text-rose-400" />
                  <span>Empresa que acolhe a comunidade LGBTQ+</span>
                </span>
              </div>

            </div>

          </div>

          {/* Right Column: Mascote Interativo & Dynamic Effect Stage */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            <MascotEffectStage />
          </div>

        </div>
      </div>
    </section>
  );
};
