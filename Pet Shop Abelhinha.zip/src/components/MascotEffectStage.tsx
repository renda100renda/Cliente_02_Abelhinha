import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Heart, Sparkles, Volume2, VolumeX, Maximize2, ShieldCheck, Award, X, Smile, Download, Check, Eye } from 'lucide-react';
import beeCatMascotImg from '../assets/images/bee_cat_mascot_transparent.png';

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
  symbol: string;
}

export const MascotEffectStage: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [glare, setGlare] = useState({ x: 50, y: 50, opacity: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [carinhoCount, setCarinhoCount] = useState(24);
  const [isBouncing, setIsBouncing] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [currentMood, setCurrentMood] = useState<'feliz' | 'amor' | 'curiosa'>('feliz');
  const [previewBg, setPreviewBg] = useState<'dark' | 'grid' | 'light'>('grid');

  // Web Audio API gentle pentatonic chime sound
  const playChimeSound = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();

      // Pentatonic pleasant chime notes
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);

        gain.gain.setValueAtTime(0, ctx.currentTime + idx * 0.08);
        gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.08 + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(ctx.currentTime + idx * 0.08);
        osc.stop(ctx.currentTime + idx * 0.08 + 0.55);
      });
    } catch {
      // Audio context might be restricted before interaction
    }
  }, [soundEnabled]);

  // Handle 3D Parallax Tilt Effect
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const tiltX = -((y - centerY) / centerY) * 12; // max 12 deg
    const tiltY = ((x - centerX) / centerX) * 12;

    setTilt({ x: tiltX, y: tiltY });
    setGlare({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100,
      opacity: 0.35,
    });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setTilt({ x: 0, y: 0 });
    setGlare((prev) => ({ ...prev, opacity: 0 }));
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  // Carinho Interaction Trigger
  const triggerCarinho = (e?: React.MouseEvent) => {
    setCarinhoCount((prev) => prev + 1);
    setIsBouncing(true);
    playChimeSound();

    const moods: ('feliz' | 'amor' | 'curiosa')[] = ['amor', 'feliz', 'curiosa'];
    setCurrentMood(moods[Math.floor(Math.random() * moods.length)]);

    // Generate burst particles
    const rect = cardRef.current?.getBoundingClientRect();
    const clickX = e && rect ? e.clientX - rect.left : 200;
    const clickY = e && rect ? e.clientY - rect.top : 200;

    const newParticles: Particle[] = [];
    const symbols = ['❤️', '✨', '🍯', '🐾', '💛', '🌸'];

    for (let i = 0; i < 6; i++) {
      newParticles.push({
        id: Date.now() + i,
        x: clickX + (Math.random() - 0.5) * 80,
        y: clickY + (Math.random() - 0.5) * 80,
        size: 16 + Math.random() * 12,
        color: ['#E0A96D', '#FDE047', '#F43F5E', '#38BDF8'][i % 4],
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
      });
    }

    setParticles((prev) => [...prev, ...newParticles]);

    setTimeout(() => {
      setIsBouncing(false);
    }, 600);

    setTimeout(() => {
      setParticles((prev) => prev.filter((p) => !newParticles.find((np) => np.id === p.id)));
    }, 1400);
  };

  return (
    <div className="w-full flex flex-col items-center justify-center relative select-none">
      
      {/* Outer Floating Ambient Glows */}
      <div className="absolute -top-10 -right-10 w-64 h-64 bg-[#E0A96D]/15 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-amber-400/10 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-cyan-400/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Main 3D Card Stage with Parallax */}
      <div
        ref={containerRef}
        className="relative w-full max-w-[460px] aspect-[1/1] sm:aspect-[1/1] perspective-1000 p-3"
      >
        <div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          onClick={triggerCarinho}
          style={{
            transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg) scale3d(${isHovered ? 1.02 : 1}, ${isHovered ? 1.02 : 1}, 1)`,
            transition: isHovered ? 'transform 0.08s ease-out' : 'transform 0.5s ease-out',
          }}
          className="relative w-full h-full rounded-3xl bg-gradient-to-b from-[#18222E] via-[#121922] to-[#0D1219] border border-[#E0A96D]/40 p-4 sm:p-5 shadow-[0_25px_60px_rgba(0,0,0,0.7)] flex flex-col items-center justify-between overflow-hidden cursor-pointer group"
        >
          {/* Inner Light Flare that tracks cursor */}
          <div
            className="absolute inset-0 pointer-events-none transition-opacity duration-300 rounded-3xl"
            style={{
              background: `radial-gradient(circle at ${glare.x}% ${glare.y}%, rgba(254, 240, 138, 0.22) 0%, transparent 60%)`,
              opacity: glare.opacity,
            }}
          />

          {/* Animated Background Geometric Pattern & Orbit Rings */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            {/* Outer Golden Orbit Ring */}
            <div className="w-[320px] h-[320px] rounded-full border border-[#E0A96D]/20 border-dashed animate-[spin_40s_linear_infinite]" />
            {/* Inner Glowing Ring */}
            <div className="absolute w-[240px] h-[240px] rounded-full border border-amber-400/25 animate-[spin_25s_linear_infinite_reverse]" />
            {/* Halo backlight behind mascot */}
            <div className="absolute w-52 h-52 rounded-full bg-gradient-to-tr from-[#E0A96D]/20 via-amber-400/15 to-cyan-300/10 blur-2xl" />
          </div>

          {/* Top Status Bar of the Stage */}
          <div className="w-full flex items-center justify-between z-20 relative pointer-events-none">
            {/* Mascot Status Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0D131A]/90 backdrop-blur-md border border-[#E0A96D]/40 text-xs shadow-md">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500" />
              </span>
              <span className="font-bold text-[#E0A96D]">Mascote Oficial</span>
              <span className="text-stone-500">•</span>
              <span className="text-amber-200 font-medium text-[11px]">Gatinha Abelhinha</span>
            </div>

            {/* Audio Toggle & Zoom controls */}
            <div className="flex items-center gap-1.5 pointer-events-auto">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSoundEnabled(!soundEnabled);
                }}
                className="p-1.5 rounded-lg bg-[#141B24]/90 hover:bg-[#1E2937] text-stone-300 hover:text-amber-300 border border-stone-700 transition-colors shadow-sm"
                title={soundEnabled ? 'Silenciar carinho' : 'Ativar som de carinho'}
                aria-label="Som"
              >
                {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5 text-stone-500" />}
              </button>

              <a
                href="/bee_cat_mascot_transparent.png"
                download="mascote_aupetmiau_transparente.png"
                onClick={(e) => e.stopPropagation()}
                className="p-1.5 rounded-lg bg-[#141B24]/90 hover:bg-[#1E2937] text-stone-300 hover:text-emerald-400 border border-stone-700 transition-colors shadow-sm inline-flex items-center justify-center"
                title="Baixar PNG transparente (sem fundo)"
                aria-label="Baixar PNG"
              >
                <Download className="w-3.5 h-3.5" />
              </a>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowDetailModal(true);
                }}
                className="p-1.5 rounded-lg bg-[#141B24]/90 hover:bg-[#1E2937] text-stone-300 hover:text-[#E0A96D] border border-stone-700 transition-colors shadow-sm"
                title="Ampliar ilustração e ver detalhes"
                aria-label="Ampliar"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Central Character Showcase with Float & Breathing Animation */}
          <div className="relative z-10 w-full flex-1 flex items-center justify-center py-2">
            
            {/* Mascot Character Wrapper with Gentle Breathing Float */}
            <div
              className={`relative flex items-center justify-center transition-transform duration-300 ${
                isBouncing ? 'scale-110 -translate-y-2' : isHovered ? 'scale-105' : 'animate-[bounce_5s_ease-in-out_infinite]'
              }`}
            >
              {/* Pedestal / Soft Circular Light Platform */}
              <div className="absolute -bottom-4 w-48 h-10 rounded-full bg-gradient-to-r from-transparent via-[#E0A96D]/30 to-transparent blur-md" />

              {/* Character Illustration - Clean Transparent PNG */}
              <div className="relative w-56 h-56 sm:w-64 sm:h-64 p-1 flex items-center justify-center">
                <img
                  src={beeCatMascotImg}
                  alt="Mascote AUpetMIAU: Gatinha com fantasia de abelha em PNG com fundo transparente"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain filter drop-shadow-[0_16px_28px_rgba(224,169,109,0.38)] transition-all duration-300 pointer-events-none"
                />

                {/* Sparkling Highlights Orbiting */}
                <div className="absolute top-2 right-4 text-amber-300 animate-pulse text-xs">✨</div>
                <div className="absolute bottom-6 left-3 text-cyan-300 animate-pulse text-xs delay-300">✦</div>
                <div className="absolute top-10 left-6 text-amber-400 animate-pulse text-xs delay-700">★</div>
              </div>

              {/* Floating Flying Particles on click */}
              {particles.map((p) => (
                <div
                  key={p.id}
                  className="absolute pointer-events-none animate-ping text-base font-bold drop-shadow-lg z-30"
                  style={{
                    left: `${p.x}px`,
                    top: `${p.y}px`,
                    color: p.color,
                  }}
                >
                  {p.symbol}
                </div>
              ))}

              {/* Happy Speech Bubble Indicator */}
              {isBouncing && (
                <div className="absolute -top-7 px-3 py-1 rounded-full bg-gradient-to-r from-amber-400 to-[#E0A96D] text-stone-950 text-xs font-black shadow-xl animate-bounce flex items-center gap-1 z-30">
                  <span>❤️ Ronronando de alegria!</span>
                </div>
              )}
            </div>

          </div>

          {/* Bottom Interactive Bar of the Stage */}
          <div className="w-full z-20 relative bg-[#0D141C]/90 backdrop-blur-md rounded-2xl p-2.5 sm:p-3 border border-stone-800 flex items-center justify-between gap-3 shadow-lg">
            
            {/* Left: Hint & Mood */}
            <div className="flex items-center gap-2.5 text-left">
              <div className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-sm">
                🐝
              </div>
              <div>
                <div className="text-[11px] font-bold text-stone-200 flex items-center gap-1.5">
                  <span>Toque para fazer carinho</span>
                  <span className="text-amber-400 font-normal">({carinhoCount} mimos)</span>
                </div>
                <p className="text-[10px] text-stone-400">
                  Gatinha fofa com capuz e asas de abelha
                </p>
              </div>
            </div>

            {/* Right: Quick Pet Button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                triggerCarinho(e);
              }}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#E0A96D] to-[#D0965A] hover:from-[#F0B87C] hover:to-[#E2A66D] text-stone-950 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer shrink-0"
            >
              <Heart className="w-3.5 h-3.5 fill-current text-rose-800" />
              <span>Mimar</span>
            </button>

          </div>

        </div>
      </div>

      {/* Floating Description Sub-pill */}
      <div className="mt-3 flex items-center gap-2 text-xs text-stone-400">
        <Sparkles className="w-3.5 h-3.5 text-[#E0A96D]" />
        <span>Inspirado no amor incondicional pelos nossos cãezinhos e gatinhos</span>
      </div>

      {/* Full Detail Mascot Inspection Modal */}
      {showDetailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/85 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-lg bg-[#111720] border border-[#E0A96D]/50 rounded-3xl p-6 shadow-2xl overflow-hidden">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-stone-800">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#E0A96D]/20 text-[#E0A96D] flex items-center justify-center text-sm font-bold">
                  🐝
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-100 font-serif-luxury">
                    Mascote AUpetMIAU · Detalhes de Criação
                  </h3>
                  <p className="text-xs text-[#E0A96D]">Ilustração Premium Estilo Mascote Cartoon</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowDetailModal(false)}
                className="p-1.5 rounded-xl bg-[#17202B] hover:bg-[#202C3B] text-stone-300 hover:text-white border border-stone-700 transition-colors"
                aria-label="Fechar modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Background Preview Mode Selector */}
            <div className="mt-4 flex items-center justify-between gap-2 bg-[#0C121A] p-2 rounded-xl border border-stone-800 text-xs">
              <span className="text-stone-400 font-medium flex items-center gap-1.5 pl-1">
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>Testar Transparência:</span>
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setPreviewBg('grid')}
                  className={`px-2.5 py-1 rounded-lg font-medium text-[11px] transition-colors ${
                    previewBg === 'grid'
                      ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Xadrez (Alpha)
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewBg('dark')}
                  className={`px-2.5 py-1 rounded-lg font-medium text-[11px] transition-colors ${
                    previewBg === 'dark'
                      ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Escuro
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewBg('light')}
                  className={`px-2.5 py-1 rounded-lg font-medium text-[11px] transition-colors ${
                    previewBg === 'light'
                      ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Claro
                </button>
              </div>
            </div>

            {/* Modal Image Display with Dynamic Background */}
            <div
              className={`my-4 flex items-center justify-center rounded-2xl p-6 border border-stone-800 relative transition-all duration-300 ${
                previewBg === 'grid'
                  ? 'bg-[radial-gradient(#475569_1px,transparent_1px)] [background-size:16px_16px] bg-[#1e293b]'
                  : previewBg === 'light'
                  ? 'bg-stone-100'
                  : 'bg-[#0B0F15]'
              }`}
            >
              <div className="w-64 h-64 sm:w-72 sm:h-72 relative flex items-center justify-center">
                <img
                  src={beeCatMascotImg}
                  alt="Mascote AUpetMIAU sem fundo (transparente)"
                  referrerPolicy="no-referrer"
                  className={`w-full h-full object-contain filter transition-all duration-300 ${
                    previewBg === 'light'
                      ? 'drop-shadow-[0_12px_24px_rgba(0,0,0,0.18)]'
                      : 'drop-shadow-[0_15px_30px_rgba(224,169,109,0.4)]'
                  }`}
                />
              </div>

              {/* Verified Transparent Badge */}
              <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold flex items-center gap-1 shadow-sm">
                <Check className="w-3 h-3 text-emerald-400" />
                <span>PNG 100% Transparente</span>
              </div>
            </div>

            {/* Character Features Checklist */}
            <div className="space-y-2 text-xs text-stone-300">
              <div className="p-2 rounded-xl bg-[#141C26] border border-stone-800 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-stone-100">Fundo 100% Transparente:</strong> Sem bordas brancas e sem falso xadrez embutido. Pronto para uso em qualquer cor ou estampa.
                </div>
              </div>

              <div className="p-2 rounded-xl bg-[#141C26] border border-stone-800 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#E0A96D] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-stone-100">Detalhes Íntegros:</strong> Capuz amarelo, anteninhas, olhos dourados com brilho, asas azuis e listras da abelha preservados em alta resolução (1024×1024).
                </div>
              </div>
            </div>

            {/* Action footer with direct download */}
            <div className="mt-5 pt-4 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <a
                href="/bee_cat_mascot_transparent.png"
                download="mascote_aupetmiau_transparente.png"
                className="w-full sm:w-auto py-2.5 px-5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-stone-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>Baixar PNG Sem Fundo</span>
              </a>

              <button
                type="button"
                onClick={() => setShowDetailModal(false)}
                className="w-full sm:w-auto py-2.5 px-6 rounded-xl bg-[#1E2733] hover:bg-[#283544] text-stone-200 hover:text-white font-semibold text-xs transition-colors cursor-pointer text-center"
              >
                Fechar
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
