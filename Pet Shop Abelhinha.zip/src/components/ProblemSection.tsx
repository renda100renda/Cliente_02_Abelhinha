import React from 'react';
import { AlertCircle, Lock, Scissors, Clock } from 'lucide-react';

export const ProblemSection: React.FC = () => {
  const problems = [
    {
      icon: AlertCircle,
      title: 'Seu pet volta assustado, amuado ou tremendo?',
      description:
        'A maioria dos pet shops tradicionais funciona como uma linha de montagem acelerada. O animal é contido à força, passa por barulhos ensurdecedores e volta para casa traumatizado por dias.',
      impact: 'Trauma comportamental e medo crônico de tomar banho.'
    },
    {
      icon: Lock,
      title: 'Preso por horas em gaiolas de metal escuras?',
      description:
        'Ver seu pet trancado em cubículos metálicos enquanto espera a vez dele parte o coração. O confinamento e a solidão geram picos de cortisol e estresse severo em cães e gatos.',
      impact: 'Sensação de abandono e ansiedade de separação.'
    },
    {
      icon: Scissors,
      title: 'Tosas agressivas na máquina que danificam a pelagem?',
      description:
        'Raças de pelo duplo (como Spitz Alemão, Chow Chow e Golden) nunca devem ser raspadas na máquina. A falta de conhecimento técnico dos tosadores tradicionais causa a temida alopécia pós-tosa.',
      impact: 'Pelo que não cresce mais e perda da proteção térmica natural.'
    },
    {
      icon: Clock,
      title: 'Falta de tempo e estresse no trânsito de São Paulo?',
      description:
        'Com a rotina corrida no Morumbi e Vila Sônia, perder 1 ou 2 horas no trânsito apenas para levar e buscar o pet é exaustivo — e transportes descuidados deixam o pet em perigo.',
      impact: 'Perda de tempo precioso e insegurança com o transporte.'
    }
  ];

  return (
    <section className="py-20 lg:py-24 bg-[#090D11] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/25 text-rose-300 text-xs font-semibold tracking-wider uppercase mb-3">
            <span>Você também passa por isso?</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            O banho do seu pet se transformou em um momento de angústia?
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            A maioria dos donos de pets em São Paulo aceita experiências traumáticas simplesmente por não saber que existe uma alternativa com respeito, carinho e sem gaiolas.
          </p>
        </div>

        {/* Problems Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {problems.map((p, idx) => {
            const Icon = p.icon;
            return (
              <div
                key={idx}
                className="p-7 rounded-2xl bg-[#10161D] border border-stone-800/90 hover:border-rose-500/30 transition-all duration-300 flex flex-col justify-between group shadow-lg"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center mb-5 border border-rose-500/20 group-hover:scale-105 transition-transform">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-stone-100 mb-2.5">
                    {p.title}
                  </h3>
                  <p className="text-sm text-stone-400 leading-relaxed">
                    {p.description}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-stone-800/80 flex items-center gap-2 text-xs text-rose-300/90 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                  <span>Consequência: {p.impact}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bridge to Solution */}
        <div className="mt-12 text-center">
          <div className="inline-block p-4 rounded-2xl bg-[#121820] border border-stone-800 text-stone-300 text-sm max-w-2xl">
            💡 <strong className="text-white">A boa notícia:</strong> O cuidado com seu pet pode ser uma experiência relaxante de SPA. Conheça o padrão <span className="text-[#E0A96D] font-bold">AUpetMIAU</span>.
          </div>
        </div>

      </div>
    </section>
  );
};
