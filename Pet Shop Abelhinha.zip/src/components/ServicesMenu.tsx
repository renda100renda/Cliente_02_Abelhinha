import React from 'react';
import { Sparkles, Scissors, HeartHandshake, Car, Check, ArrowRight } from 'lucide-react';
import { SERVICES, UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const ServicesMenu: React.FC = () => {
  const iconMap: Record<string, React.ElementType> = {
    Sparkles,
    Scissors,
    HeartHandshake,
    Car
  };

  const handleBookService = (serviceName: string) => {
    const unit = UNITS['vila-sonia'];
    const msg = encodeURIComponent(
      `Olá, AUpetMIAU! Gostaria de agendar o serviço de *${serviceName}* para meu pet. Como estão os horários desta semana?`
    );
    openWhatsAppWithTracking(`https://wa.me/${unit.phoneRaw}?text=${msg}`, 'service_card_booking', unit.name);
  };

  return (
    <section id="servicos" className="py-20 lg:py-28 bg-[#090D11] relative scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3">
            <span>Cardápio de Cuidados</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            O Que Está Incluído no Seu Agendamento
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            Transparência total sobre cada etapa do procedimento. Sem surpresas, sem letras miúdas e com carinho incondicional.
          </p>
        </div>

        {/* Services Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((srv) => {
            const Icon = iconMap[srv.iconName] || Sparkles;
            const isHighlight = srv.id === 'scissor-grooming';

            return (
              <div
                key={srv.id}
                className={`p-7 sm:p-8 rounded-2xl bg-[#11171E] border transition-all flex flex-col justify-between shadow-xl relative ${
                  isHighlight
                    ? 'border-[#E0A96D] ring-1 ring-[#E0A96D]/50 glow-gold-subtle'
                    : 'border-stone-800 hover:border-stone-700'
                }`}
              >
                {isHighlight && (
                  <div className="absolute -top-3.5 right-6 px-3 py-1 rounded-full bg-gradient-to-r from-[#E0A96D] to-[#CCA067] text-stone-950 font-extrabold text-[11px] uppercase tracking-wider shadow-md">
                    ★ Especialidade Mais Elogiada
                  </div>
                )}

                <div>
                  <div className="flex items-center gap-3.5 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-[#E0A96D]/10 text-[#E0A96D] flex items-center justify-center border border-[#E0A96D]/20">
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white font-sans">
                        {srv.name}
                      </h3>
                      <p className="text-xs text-stone-400 font-medium">{srv.tagline}</p>
                    </div>
                  </div>

                  <p className="text-sm text-stone-300 leading-relaxed mb-6">
                    {srv.description}
                  </p>

                  <div className="text-xs font-semibold uppercase tracking-wider text-[#E0A96D] mb-3">
                    Entregáveis e Cuidados Inclusos:
                  </div>

                  <ul className="space-y-2.5 mb-6">
                    {srv.deliverables.map((d, dIdx) => (
                      <li key={dIdx} className="flex items-start gap-2.5 text-xs text-stone-300">
                        <div className="p-0.5 rounded-full bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                          <Check className="w-3.5 h-3.5" />
                        </div>
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-5 border-t border-stone-800">
                  <div className="text-[11px] text-stone-400 mb-4">
                    🎯 <strong>Recomendado para:</strong> {srv.recommendedFor}
                  </div>

                  <button
                    type="button"
                    onClick={() => handleBookService(srv.name)}
                    className="w-full py-3.5 px-5 rounded-xl bg-[#17212C] hover:bg-[#E0A96D] text-stone-200 hover:text-stone-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer border border-stone-700 hover:border-[#E0A96D]"
                  >
                    <span>Consultar Horários para {srv.name}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
