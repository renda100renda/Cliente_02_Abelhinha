import React from 'react';
import { MessageCircle, Sparkles, ShieldCheck, Heart, ArrowRight } from 'lucide-react';
import { UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const FinalCta: React.FC = () => {
  const defaultUnit = UNITS['vila-sonia'];

  const handleFinalCtaClick = () => {
    openWhatsAppWithTracking(defaultUnit.whatsappLink, 'final_bottom_cta', defaultUnit.name);
  };

  return (
    <section className="py-24 lg:py-32 relative bg-[#090D10] overflow-hidden border-t border-stone-800">
      {/* Cinematic Lighting Rings */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#E0A96D]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-0 right-10 w-96 h-96 bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        {/* Top Eyebrow */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#161F28] border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-6 shadow-md">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Chega de Banho com Estresse</span>
        </div>

        {/* Powerful Headline selling the result */}
        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-serif-luxury font-black text-white tracking-tight leading-tight mb-6">
          Pronto para ver seu pet limpo, perfumado e <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F5D5B2] via-[#E0A96D] to-[#CCA067]">sem nenhum trauma</span>?
        </h2>

        {/* Objective Subheading */}
        <p className="text-base sm:text-xl text-stone-300 max-w-2xl mx-auto mb-10 leading-relaxed">
          Reserve o horário do seu cão ou gato na <strong className="text-white">AUpetMIAU</strong>. Atendimento humanizado sem gaiolas, tosa especializada e Táxi Dog na porta da sua casa.
        </p>

        {/* Standout Main CTA Button */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            type="button"
            onClick={handleFinalCtaClick}
            className="w-full sm:w-auto py-4 px-8 rounded-xl bg-gradient-to-r from-[#E0A96D] via-[#CCA067] to-[#B37F47] hover:from-[#F0B87C] hover:to-[#DBAE76] text-stone-950 font-extrabold text-base flex items-center justify-center gap-3 shadow-2xl transition-all hover:scale-105 active:scale-95 cursor-pointer glow-gold-hover"
          >
            <MessageCircle className="w-5 h-5 fill-current" />
            <span>Agendar Banho & SPA no WhatsApp</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <a
            href="#simulador"
            className="w-full sm:w-auto py-4 px-6 rounded-xl bg-[#131A22] hover:bg-[#1A232E] border border-stone-800 text-stone-300 hover:text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
          >
            <span>Calcular Táxi Dog no Simulador</span>
          </a>
        </div>

        {/* Micro-assurances */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-stone-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Zero Gaiolas ou Confinamento
          </span>
          <span>•</span>
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-400" />
            Fotos Fofas Enviadas no WhatsApp
          </span>
          <span>•</span>
          <span className="flex items-center gap-1.5">
            <Heart className="w-4 h-4 text-rose-400" />
            Paciência para Cães Sensíveis
          </span>
        </div>

      </div>
    </section>
  );
};
