import React from 'react';
import { HeartHandshake, Shield, Sparkles, Car, Camera, Award } from 'lucide-react';

export const BenefitsSection: React.FC = () => {
  const benefits = [
    {
      icon: HeartHandshake,
      title: 'Você conversa com quem tem paciência real para cães reativos',
      description:
        'Se o seu cão tem medo de banho ou trauma de experiências anteriores, aqui ele não é obrigado nem repreendido. Adaptamos o ritmo com afeto e petiscos.',
      tag: 'Paciência Comprovada'
    },
    {
      icon: Shield,
      title: 'Coração tranquilo: seu pet solto e confortável pela loja',
      description:
        'Nada de baias frias ou enclausuramento. O pet socializa, caminha livre pelo espaço climatizado e espera com conforto e acolhimento humano.',
      tag: 'Zero Gaiolas'
    },
    {
      icon: Sparkles,
      title: 'Tosa na tesoura que preserva a pelagem natural da raça',
      description:
        'Para Spitz Alemão, Poodle, Maltês e Shih-tzu: escultura anatômica que não agride o subpêlo, evitando alopécia e mantendo a proteção térmica.',
      tag: 'Padrão Internacional'
    },
    {
      icon: Car,
      title: 'Economize horas no trânsito com nosso Táxi Dog VIP',
      description:
        'Buscamos e entregamos seu pet na sua residência ou condomínio no Morumbi, Vila Suzana, Vila Sônia e região em veículo seguro e climatizado.',
      tag: 'Comodidade Total'
    },
    {
      icon: Camera,
      title: 'Receba fotos fofas de estúdio no WhatsApp a cada visita',
      description:
        'Você não precisa esperar ele chegar em casa para conferir o resultado. Enviamos fotos e vídeos encantadores do seu pet pronto.',
      tag: 'Transparência Afetiva'
    },
    {
      icon: Award,
      title: 'Cosméticos nobres hipoalergênicos que não irritam a pele',
      description:
        'Fórmulas com pH equilibrado, livres de químicos agressivos, que deixam o pelo macio como veludo e com perfume agradável por muitos dias.',
      tag: 'Alta Cosmética Pet'
    }
  ];

  return (
    <section id="diferenciais" className="py-20 lg:py-28 bg-[#0A0E12] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3">
            <span>Benefícios Reais</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            Mais do Que um Pet Shop: Uma Experiência de Amor e Respeito
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            Veja o que muda na sua rotina e na vida do seu pet quando você escolhe um padrão boutique de verdade.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {benefits.map((b, idx) => {
            const Icon = b.icon;
            return (
              <div
                key={idx}
                className="p-7 rounded-2xl bg-[#11171E] border border-stone-800 hover:border-[#E0A96D]/40 transition-all duration-300 flex flex-col justify-between group shadow-lg"
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-12 h-12 rounded-xl bg-[#E0A96D]/10 text-[#E0A96D] flex items-center justify-center border border-[#E0A96D]/20 group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-semibold px-2.5 py-1 rounded-md bg-[#16212B] text-[#E0A96D] border border-stone-800">
                      {b.tag}
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-bold text-stone-100 mb-2.5 leading-snug">
                    {b.title}
                  </h3>
                  <p className="text-sm text-stone-400 leading-relaxed">
                    {b.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
