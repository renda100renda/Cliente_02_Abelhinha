import React, { useState, useEffect } from 'react';
import { Sparkles, MessageCircle, Menu, X, MapPin, Star } from 'lucide-react';
import { UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';
import beeCatMascotImg from '../assets/images/bee_cat_mascot_transparent.png';

interface NavbarProps {
  onOpenBookingModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedUnitKey, setSelectedUnitKey] = useState<'vila-sonia' | 'morumbi'>('vila-sonia');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const currentUnit = UNITS[selectedUnitKey];

  const handleNavWhatsApp = () => {
    openWhatsAppWithTracking(currentUnit.whatsappLink, 'navbar_cta', currentUnit.name);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#0B0F13]/90 backdrop-blur-md border-b border-stone-800/80 py-3 shadow-lg'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo & Brand Identity */}
          <a href="#" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#E0A96D] to-[#B37F47] p-0.5 flex items-center justify-center text-stone-950 font-black text-xl shadow-md transition-transform group-hover:scale-105 overflow-hidden">
              <img
                src={beeCatMascotImg}
                alt="AUpetMIAU Mascote"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover rounded-[10px]"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg sm:text-xl font-bold tracking-tight text-white font-sans">
                  AUpet<span className="text-[#E0A96D]">MIAU</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-[#E0A96D]/15 text-[#E0A96D] border border-[#E0A96D]/30 hidden sm:inline-block">
                  Boutique & SPA
                </span>
              </div>
              <p className="text-[11px] text-stone-400 font-medium flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Morumbi & Vila Sônia · 5.0 ★ Google</span>
              </p>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-300">
            <a href="#carinho-em-acao" className="hover:text-[#E0A96D] transition-colors flex items-center gap-1.5 text-stone-200">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E0A96D]" />
              <span>Carinho em Ação</span>
            </a>
            <a href="#servicos" className="hover:text-[#E0A96D] transition-colors">
              Serviços
            </a>
            <a href="#simulador" className="hover:text-[#E0A96D] transition-colors flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#E0A96D]" />
              <span>Simulador</span>
            </a>
            <a href="#depoimentos" className="hover:text-[#E0A96D] transition-colors">
              Avaliações
            </a>
            <a href="#unidades" className="hover:text-[#E0A96D] transition-colors">
              Unidades
            </a>
            <a href="#faq" className="hover:text-[#E0A96D] transition-colors">
              Dúvidas
            </a>
          </nav>

          {/* Unit Switcher & Primary CTA */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Quick unit picker */}
            <div className="inline-flex rounded-lg bg-[#121820] border border-stone-800 p-0.5 text-xs">
              <button
                onClick={() => setSelectedUnitKey('vila-sonia')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  selectedUnitKey === 'vila-sonia'
                    ? 'bg-[#E0A96D] text-stone-950 font-bold'
                    : 'text-stone-400 hover:text-white'
                }`}
                title="Unidade Vila Sônia (5.0★)"
              >
                Vila Sônia (5.0★)
              </button>
              <button
                onClick={() => setSelectedUnitKey('morumbi')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  selectedUnitKey === 'morumbi'
                    ? 'bg-[#E0A96D] text-stone-950 font-bold'
                    : 'text-stone-400 hover:text-white'
                }`}
                title="Unidade Morumbi / Vila Suzana (4.8★)"
              >
                Morumbi (4.8★)
              </button>
            </div>

            {/* Standout Primary CTA */}
            <button
              onClick={handleNavWhatsApp}
              className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-[#E0A96D] to-[#CCA067] hover:from-[#F0B87C] hover:to-[#DBAE76] text-stone-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-md transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>Agendar no WhatsApp</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={handleNavWhatsApp}
              className="py-2 px-3 rounded-lg bg-[#E0A96D] text-stone-950 font-bold text-xs flex items-center gap-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-current" />
              <span>Agendar</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-[#161F28] text-stone-300 hover:text-white border border-stone-800"
              aria-label="Abrir Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pt-4 pb-6 border-t border-stone-800/80 bg-[#0B0F13]/95 backdrop-blur-xl rounded-2xl px-4 space-y-3 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <span className="text-xs text-stone-400">Escolha sua unidade:</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setSelectedUnitKey('vila-sonia')}
                  className={`px-2.5 py-1 text-xs rounded-md ${
                    selectedUnitKey === 'vila-sonia' ? 'bg-[#E0A96D] text-stone-950 font-bold' : 'bg-stone-800 text-stone-300'
                  }`}
                >
                  Vila Sônia 5.0★
                </button>
                <button
                  onClick={() => setSelectedUnitKey('morumbi')}
                  className={`px-2.5 py-1 text-xs rounded-md ${
                    selectedUnitKey === 'morumbi' ? 'bg-[#E0A96D] text-stone-950 font-bold' : 'bg-stone-800 text-stone-300'
                  }`}
                >
                  Morumbi 4.8★
                </button>
              </div>
            </div>

            <nav className="flex flex-col space-y-2.5 text-sm text-stone-200">
              <a
                href="#carinho-em-acao"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1.5 text-[#E0A96D] font-bold flex items-center gap-2"
              >
                <span>🐾</span>
                <span>Carinho em Ação</span>
              </a>
              <a
                href="#servicos"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1.5 hover:text-[#E0A96D]"
              >
                Serviços & Pacotes
              </a>
              <a
                href="#simulador"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1.5 hover:text-[#E0A96D]"
              >
                Simulador de SPA & Táxi Dog
              </a>
              <a
                href="#depoimentos"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1.5 hover:text-[#E0A96D]"
              >
                Avaliações de Tutores
              </a>
              <a
                href="#unidades"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1.5 hover:text-[#E0A96D]"
              >
                Nossas Unidades & Endereços
              </a>
              <a
                href="#faq"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1.5 hover:text-[#E0A96D]"
              >
                Perguntas Frequentes
              </a>
            </nav>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                handleNavWhatsApp();
              }}
              className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#E0A96D] to-[#CCA067] text-stone-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>Falar no WhatsApp ({currentUnit.name})</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
