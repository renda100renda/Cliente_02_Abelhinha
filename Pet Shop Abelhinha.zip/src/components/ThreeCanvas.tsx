import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export const ThreeCanvas: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isWebGLSupported, setIsWebGLSupported] = useState(true);
  const [isPetHappy, setIsPetHappy] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Check WebGL availability
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (!gl) {
        setIsWebGLSupported(false);
        return;
      }
    } catch {
      setIsWebGLSupported(false);
      return;
    }

    // 1. Scene Setup
    const scene = new THREE.Scene();

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(
      42,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0.2, 6.2);

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // 4. Lighting - Warm Studio Luxury Lighting
    const ambientLight = new THREE.AmbientLight(0xfff5ea, 1.4);
    scene.add(ambientLight);

    // Warm Key Light (Champagne Gold)
    const keyLight = new THREE.DirectionalLight(0xffe8d6, 2.8);
    keyLight.position.set(4, 5, 5);
    scene.add(keyLight);

    // Cool/Sage Fill Light
    const fillLight = new THREE.DirectionalLight(0xdcfce7, 1.2);
    fillLight.position.set(-4, 2, 4);
    scene.add(fillLight);

    // Golden Rim Light behind for luxury silhouette
    const rimLight = new THREE.DirectionalLight(0xe0a96d, 3.5);
    rimLight.position.set(0, 4, -4);
    scene.add(rimLight);

    // 5. Materials
    const furColor = 0xF5CDA7; // Golden/Biscuit puppy fur
    const furAccentColor = 0xFFF1E2; // Cream chest & muzzle
    const earColor = 0xE2AC7B; // Slightly warmer golden ear tips
    const goldColor = 0xE0A96D; // Champagne luxury gold

    const furMaterial = new THREE.MeshStandardMaterial({
      color: furColor,
      roughness: 0.75,
      metalness: 0.05,
    });

    const creamMaterial = new THREE.MeshStandardMaterial({
      color: furAccentColor,
      roughness: 0.7,
      metalness: 0.05,
    });

    const earMaterial = new THREE.MeshStandardMaterial({
      color: earColor,
      roughness: 0.8,
      metalness: 0.05,
    });

    const noseMaterial = new THREE.MeshStandardMaterial({
      color: 0x1f1917,
      roughness: 0.25,
      metalness: 0.1,
    });

    const eyeMaterial = new THREE.MeshStandardMaterial({
      color: 0x0f0b09,
      roughness: 0.1,
      metalness: 0.8,
    });

    const eyeHighlightMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffff,
    });

    const collarMaterial = new THREE.MeshStandardMaterial({
      color: 0xB45309, // Burgundy/Cognac leather
      roughness: 0.4,
      metalness: 0.2,
    });

    const goldMedalMaterial = new THREE.MeshStandardMaterial({
      color: goldColor,
      roughness: 0.2,
      metalness: 0.9,
    });

    const bubbleMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xe0f2fe,
      transmission: 0.9,
      opacity: 0.8,
      transparent: true,
      roughness: 0.05,
      ior: 1.33,
      reflectivity: 0.9,
      clearcoat: 1.0,
    });

    // 6. Master Hierarchy
    const dogRoot = new THREE.Group();
    dogRoot.position.y = -0.4;
    scene.add(dogRoot);

    // Dog Body Group
    const bodyGroup = new THREE.Group();
    dogRoot.add(bodyGroup);

    // Torso / Chest
    const bodyGeom = new THREE.CapsuleGeometry(0.85, 1.1, 16, 32);
    const bodyMesh = new THREE.Mesh(bodyGeom, furMaterial);
    bodyMesh.position.set(0, 0.4, -0.15);
    bodyMesh.rotation.x = 0.25;
    bodyGroup.add(bodyMesh);

    // Cream Belly Patch
    const chestGeom = new THREE.SphereGeometry(0.68, 24, 24);
    const chestMesh = new THREE.Mesh(chestGeom, creamMaterial);
    chestMesh.position.set(0, 0.6, 0.35);
    chestMesh.scale.set(0.9, 1.2, 0.5);
    bodyGroup.add(chestMesh);

    // Front Paws
    const pawGeom = new THREE.SphereGeometry(0.28, 16, 16);
    const leftPaw = new THREE.Mesh(pawGeom, creamMaterial);
    leftPaw.position.set(-0.45, -0.6, 0.45);
    leftPaw.scale.set(1, 0.7, 1.3);
    bodyGroup.add(leftPaw);

    const rightPaw = leftPaw.clone();
    rightPaw.position.set(0.45, -0.6, 0.45);
    bodyGroup.add(rightPaw);

    // Collar
    const collarGeom = new THREE.TorusGeometry(0.68, 0.07, 16, 36);
    const collarMesh = new THREE.Mesh(collarGeom, collarMaterial);
    collarMesh.position.set(0, 1.15, 0.05);
    collarMesh.rotation.x = Math.PI / 2 + 0.2;
    bodyGroup.add(collarMesh);

    // Gold Luxury Medal with Paw Silhouette
    const medalGeom = new THREE.CylinderGeometry(0.14, 0.14, 0.03, 24);
    const medalMesh = new THREE.Mesh(medalGeom, goldMedalMaterial);
    medalMesh.position.set(0, 1.0, 0.62);
    medalMesh.rotation.x = Math.PI / 2;
    bodyGroup.add(medalMesh);

    // Dog Tail
    const tailGroup = new THREE.Group();
    tailGroup.position.set(0, 0.2, -0.85);
    bodyGroup.add(tailGroup);

    const tailGeom = new THREE.ConeGeometry(0.2, 0.9, 16);
    const tailMesh = new THREE.Mesh(tailGeom, furMaterial);
    tailMesh.position.set(0, 0.4, -0.2);
    tailMesh.rotation.x = -0.7;
    tailGroup.add(tailMesh);

    // Dog Head Group (tracks cursor independently)
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.6, 0.15);
    dogRoot.add(headGroup);

    // Skull
    const headGeom = new THREE.SphereGeometry(0.82, 32, 32);
    const headMesh = new THREE.Mesh(headGeom, furMaterial);
    headMesh.scale.set(1.05, 0.98, 1.0);
    headGroup.add(headMesh);

    // Snout / Muzzle
    const snoutGeom = new THREE.SphereGeometry(0.42, 24, 24);
    const snoutMesh = new THREE.Mesh(snoutGeom, creamMaterial);
    snoutMesh.position.set(0, -0.15, 0.62);
    snoutMesh.scale.set(1.0, 0.85, 1.1);
    headGroup.add(snoutMesh);

    // Nose (Shiny & wet)
    const noseGeom = new THREE.SphereGeometry(0.14, 16, 16);
    const noseMesh = new THREE.Mesh(noseGeom, noseMaterial);
    noseMesh.position.set(0, -0.05, 1.02);
    noseMesh.scale.set(1.2, 0.9, 0.8);
    headGroup.add(noseMesh);

    // Happy Tongue
    const tongueGeom = new THREE.BoxGeometry(0.16, 0.22, 0.05);
    const tongueMaterial = new THREE.MeshStandardMaterial({
      color: 0xF43F5E,
      roughness: 0.4,
    });
    const tongueMesh = new THREE.Mesh(tongueGeom, tongueMaterial);
    tongueMesh.position.set(0, -0.32, 0.85);
    tongueMesh.rotation.x = 0.35;
    headGroup.add(tongueMesh);

    // Eyes
    const eyeGeom = new THREE.SphereGeometry(0.12, 24, 24);
    const highlightGeom = new THREE.SphereGeometry(0.04, 12, 12);

    // Left Eye
    const leftEye = new THREE.Mesh(eyeGeom, eyeMaterial);
    leftEye.position.set(-0.32, 0.1, 0.72);
    headGroup.add(leftEye);

    const leftHighlight = new THREE.Mesh(highlightGeom, eyeHighlightMaterial);
    leftHighlight.position.set(-0.29, 0.14, 0.81);
    headGroup.add(leftHighlight);

    // Right Eye
    const rightEye = new THREE.Mesh(eyeGeom, eyeMaterial);
    rightEye.position.set(0.32, 0.1, 0.72);
    headGroup.add(rightEye);

    const rightHighlight = new THREE.Mesh(highlightGeom, eyeHighlightMaterial);
    rightHighlight.position.set(0.35, 0.14, 0.81);
    headGroup.add(rightHighlight);

    // Floppy Cute Ears
    const earGeom = new THREE.SphereGeometry(0.34, 24, 24);

    // Left Ear
    const leftEarGroup = new THREE.Group();
    leftEarGroup.position.set(-0.68, 0.4, 0.0);
    headGroup.add(leftEarGroup);

    const leftEarMesh = new THREE.Mesh(earGeom, earMaterial);
    leftEarMesh.scale.set(0.45, 1.5, 0.85);
    leftEarMesh.rotation.z = -0.35;
    leftEarMesh.rotation.x = 0.2;
    leftEarGroup.add(leftEarMesh);

    // Right Ear
    const rightEarGroup = new THREE.Group();
    rightEarGroup.position.set(0.68, 0.4, 0.0);
    headGroup.add(rightEarGroup);

    const rightEarMesh = new THREE.Mesh(earGeom, earMaterial);
    rightEarMesh.scale.set(0.45, 1.5, 0.85);
    rightEarMesh.rotation.z = 0.35;
    rightEarMesh.rotation.x = 0.2;
    rightEarGroup.add(rightEarMesh);

    // 7. Floating SPA Bubbles
    const bubblesGroup = new THREE.Group();
    scene.add(bubblesGroup);

    const bubbles: { mesh: THREE.Mesh; speed: number; orbitRadius: number; angle: number; yBase: number }[] = [];
    const bubbleSizes = [0.18, 0.24, 0.14, 0.28, 0.16, 0.22, 0.15];

    bubbleSizes.forEach((size, idx) => {
      const bGeom = new THREE.SphereGeometry(size, 20, 20);
      const bMesh = new THREE.Mesh(bGeom, bubbleMaterial);
      const orbit = 1.8 + idx * 0.25;
      const angle = (idx / bubbleSizes.length) * Math.PI * 2;
      const yBase = -0.2 + (idx % 3) * 0.8;
      bMesh.position.set(Math.cos(angle) * orbit, yBase, Math.sin(angle) * orbit);
      bubblesGroup.add(bMesh);
      bubbles.push({ mesh: bMesh, speed: 0.6 + idx * 0.15, orbitRadius: orbit, angle, yBase });
    });

    // 8. Luxury Halo / Warm Glow Ring on the Floor
    const haloGeom = new THREE.TorusGeometry(2.1, 0.04, 16, 64);
    const haloMaterial = new THREE.MeshBasicMaterial({
      color: 0xE0A96D,
      transparent: true,
      opacity: 0.35,
    });
    const haloMesh = new THREE.Mesh(haloGeom, haloMaterial);
    haloMesh.rotation.x = Math.PI / 2;
    haloMesh.position.y = -1.2;
    scene.add(haloMesh);

    // 9. Interactive Mouse Tracking
    const mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouse.targetX = THREE.MathUtils.clamp(x, -1, 1);
      mouse.targetY = THREE.MathUtils.clamp(y, -1, 1);
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const rect = container.getBoundingClientRect();
        const x = ((e.touches[0].clientX - rect.left) / rect.width) * 2 - 1;
        const y = -(((e.touches[0].clientY - rect.top) / rect.height) * 2 - 1);
        mouse.targetX = THREE.MathUtils.clamp(x, -1, 1);
        mouse.targetY = THREE.MathUtils.clamp(y, -1, 1);
      }
    };

    const handleContainerClick = () => {
      setIsPetHappy(true);
      setTimeout(() => setIsPetHappy(false), 1600);
    };

    window.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('touchmove', handleTouchMove, { passive: true });
    container.addEventListener('click', handleContainerClick);

    // 10. Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();
    let isVisible = true;

    // IntersectionObserver to pause rendering when off-screen
    const observer = new IntersectionObserver(
      ([entry]) => {
        isVisible = entry.isIntersecting;
      },
      { threshold: 0.05 }
    );
    observer.observe(container);

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (!isVisible) return;

      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      // Smooth mouse interpolation
      mouse.x += (mouse.targetX - mouse.x) * 0.08;
      mouse.y += (mouse.targetY - mouse.y) * 0.08;

      // 1. Dog Head Tracking (looks at cursor)
      headGroup.rotation.y = mouse.x * 0.45;
      headGroup.rotation.x = -mouse.y * 0.35;
      headGroup.rotation.z = -mouse.x * 0.12;

      // 2. Ear Jiggle / Physics
      leftEarGroup.rotation.z = Math.sin(time * 3) * 0.05 - mouse.x * 0.2;
      rightEarGroup.rotation.z = -Math.sin(time * 3) * 0.05 - mouse.x * 0.2;

      // 3. Tail Wagging (excited puppy!)
      const wagSpeed = isPetHappy ? 16 : 8;
      const wagAngle = isPetHappy ? 0.65 : 0.35;
      tailGroup.rotation.y = Math.sin(time * wagSpeed) * wagAngle;

      // 4. Subtle Body Breathing Bob
      bodyGroup.position.y = Math.sin(time * 2.2) * 0.035;
      if (isPetHappy) {
        dogRoot.position.y = -0.4 + Math.abs(Math.sin(time * 7)) * 0.12;
      } else {
        dogRoot.position.y = -0.4;
      }

      // 5. Bubbles Orbiting Animation
      bubbles.forEach((b) => {
        b.angle += b.speed * delta * 0.6;
        b.mesh.position.x = Math.cos(b.angle) * b.orbitRadius;
        b.mesh.position.z = Math.sin(b.angle) * b.orbitRadius;
        b.mesh.position.y = b.yBase + Math.sin(time * 1.8 + b.speed) * 0.25;
      });

      // 6. Luxury Halo Rotation
      haloMesh.rotation.z = time * 0.2;

      renderer.render(scene, camera);
    };

    animate();

    // 11. Responsive Resize
    const handleResize = () => {
      if (!container) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      observer.disconnect();
      window.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('touchmove', handleTouchMove);
      container.removeEventListener('click', handleContainerClick);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [isPetHappy]);

  if (!isWebGLSupported) {
    return (
      <div className="w-full h-full flex items-center justify-center p-6 text-center">
        <div className="p-4 rounded-2xl bg-[#141A23] border border-[#E0A96D]/30 text-stone-300 text-xs">
          🐾 <strong>AUpetMIAU SPA Pet 3D</strong>
          <p className="mt-1 text-stone-400">Ambiente interativo pronto.</p>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="w-full h-full relative cursor-grab active:cursor-grabbing select-none"
      title="Passe o mouse para interagir ou clique para fazer carinho no pet!"
    >
      {/* Click feedback indicator */}
      {isPetHappy && (
        <div className="absolute top-6 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-[#E0A96D] text-stone-950 text-xs font-black shadow-lg animate-bounce pointer-events-none">
          ❤️ Carinho recebido!
        </div>
      )}
    </div>
  );
};
