import React from 'react';
import { Heart, MapPin, Phone, Instagram, Star, ShieldCheck, ArrowUp } from 'lucide-react';
import { UNITS } from '../data/content';
import beeCatMascotImg from '../assets/images/bee_cat_mascot_transparent.png';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#070A0D] text-stone-400 text-xs border-t border-stone-800/90 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-stone-800/80">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#E0A96D] to-[#B37F47] p-0.5 overflow-hidden flex items-center justify-center text-stone-950 font-bold text-base shadow-md">
                <img
                  src={beeCatMascotImg}
                  alt="Mascote AUpetMIAU"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover rounded-[7px]"
                />
              </div>
              <span className="text-lg font-bold text-white tracking-tight font-sans">
                AUpet<span className="text-[#E0A96D]">MIAU</span> Boutique & SPA
              </span>
            </div>

            <p className="text-stone-400 text-xs leading-relaxed max-w-sm">
              Referência em banho e tosa de alto padrão, tosa na tesoura no padrão da raça e atendimento afetivo para cães reativos sem gaiolas na Zona Sul de São Paulo.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-[#11171E] hover:bg-[#1A232E] text-stone-300 hover:text-[#E0A96D] border border-stone-800 transition-colors flex items-center gap-1.5"
              >
                <Instagram className="w-4 h-4" />
                <span>Instagram</span>
              </a>
              <div className="px-3 py-1.5 rounded-lg bg-[#11171E] border border-stone-800 text-stone-300 flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-current text-amber-400" />
                <span>4.9 ★ Média Google</span>
              </div>
            </div>
          </div>

          {/* Unidade Morumbi */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#E0A96D]" />
              <span>Unidade Morumbi</span>
            </h4>
            <p className="text-stone-300 font-medium">Aupetmiau Morumbi (4,8 ★)</p>
            <p className="text-stone-400 mt-1">R. Mal. Hastimphilo de Moura, 277</p>
            <p className="text-stone-400">Vila Suzana, São Paulo - SP</p>
            <p className="text-stone-400">CEP 05641-000</p>
            <p className="mt-2 font-mono text-stone-300">(11) 96708-7583</p>
            <a
              href={UNITS['morumbi'].googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block mt-2 text-[11px] text-[#E0A96D] hover:underline"
            >
              Rotas no Google Maps →
            </a>
          </div>

          {/* Unidade Vila Sônia */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#E0A96D]" />
              <span>Unidade Vila Sônia</span>
            </h4>
            <p className="text-stone-300 font-medium">AUpetMIAU Boutique & SPA II (5,0 ★)</p>
            <p className="text-stone-400 mt-1">Rua Dr. Sílvio Dante Bertacchi, 534</p>
            <p className="text-stone-400">Vila Sônia, São Paulo - SP</p>
            <p className="text-stone-400">CEP 05625-000</p>
            <p className="mt-2 font-mono text-stone-300">(11) 99765-4154</p>
            <a
              href={UNITS['vila-sonia'].googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block mt-2 text-[11px] text-[#E0A96D] hover:underline"
            >
              Rotas no Google Maps →
            </a>
          </div>

          {/* Navigation & Values */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Navegação
            </h4>
            <ul className="space-y-2">
              <li>
                <a href="#diferenciais" className="hover:text-white transition-colors">
                  Por Que Escolher
                </a>
              </li>
              <li>
                <a href="#ritual" className="hover:text-white transition-colors">
                  O Ritual de SPA
                </a>
              </li>
              <li>
                <a href="#simulador" className="text-[#E0A96D] hover:underline">
                  Simulador de Agendamento
                </a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-white transition-colors">
                  Depoimentos de Tutores
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  Perguntas Frequentes
                </a>
              </li>
            </ul>

            <div className="mt-4 pt-3 border-t border-stone-800">
              <p className="text-[11px] text-stone-400">
                🌈 Empresa inclusiva que acolhe a comunidade LGBTQ+ e liderada por mulheres empreendedoras.
              </p>
            </div>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-400">
          <p>© {new Date().getFullYear()} AUpetMIAU Boutique & SPA. Todos os direitos reservados.</p>
          
          <div className="flex items-center gap-4">
            <span>Zona Sul · São Paulo - SP</span>
            <span>•</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1 text-stone-300 hover:text-[#E0A96D] transition-colors cursor-pointer"
            >
              <span>Voltar ao topo</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
