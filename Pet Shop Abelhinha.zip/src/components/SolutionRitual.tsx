import React from 'react';
import { Sparkles, Heart, Scissors, Camera, CheckCircle2, ArrowRight } from 'lucide-react';
import { UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const SolutionRitual: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Chegada Acolhedora & Pet Solto',
      subtitle: 'Zero gaiolas ou pressa',
      desc: 'O pet explora o espaço, recebe carinho da equipe e se acostuma com os aromas e o ambiente. Nada de confinamento em baias metálicas frias.',
      icon: Heart,
      badge: 'Respeito ao Tempo do Pet'
    },
    {
      num: '02',
      title: 'Banho SPA & Cosmética Nobre',
      subtitle: 'Água na temperatura ideal',
      desc: 'Higienização com produtos hipoalergênicos de alta perfumaria pet, massagem suave e secagem calma com sopradores silenciosos de baixo ruído.',
      icon: Sparkles,
      badge: 'Pele Hidratada & Protegida'
    },
    {
      num: '03',
      title: 'Tosa Artística na Tesoura',
      subtitle: 'Padrão oficial da raça',
      desc: 'Escultura manual milimétrica que valoriza a elegância do seu pet sem agredir o subpêlo protetor. Especialidade pura em Spitz Alemão e raças nobres.',
      icon: Scissors,
      badge: 'Sem Risco de Alopécia'
    },
    {
      num: '04',
      title: 'Sessão de Fotos & Retorno Feliz',
      subtitle: 'Atualização no seu WhatsApp',
      desc: 'Tiramos fotos e vídeos fofos de estúdio para você se encantar antes mesmo do retorno. O pet volta no Táxi Dog relaxado e perfumado.',
      icon: Camera,
      badge: 'Transparência & Carinho'
    }
  ];

  const handleCta = () => {
    const unit = UNITS['vila-sonia'];
    openWhatsAppWithTracking(unit.whatsappLink, 'solution_ritual_cta', unit.name);
  };

  return (
    <section id="ritual" className="py-20 lg:py-28 bg-[#0D1217] relative border-t border-stone-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold tracking-wider uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>A Solução AUpetMIAU</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            O Ritual Boutique & SPA: Como Transformamos o Banho em Carinho
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            Combinamos técnica profissional de groomers experientes com um ambiente acolhedor onde seu pet é tratado como membro da família.
          </p>
        </div>

        {/* 4 Steps Visual Timeline Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((s, idx) => {
            const Icon = s.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-[#11171E] border border-stone-800 hover:border-[#E0A96D]/50 transition-all duration-300 flex flex-col justify-between group shadow-xl relative overflow-hidden"
              >
                {/* Big Step Number Watermark */}
                <div className="absolute top-2 right-4 text-5xl font-serif-luxury font-black text-stone-800/40 pointer-events-none group-hover:text-[#E0A96D]/10 transition-colors">
                  {s.num}
                </div>

                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#E0A96D]/10 text-[#E0A96D] flex items-center justify-center mb-5 border border-[#E0A96D]/20 group-hover:scale-110 transition-transform">
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#E0A96D] mb-1">
                    Passo {s.num}
                  </div>
                  <h3 className="text-lg font-bold text-stone-100 mb-1">
                    {s.title}
                  </h3>
                  <p className="text-xs text-emerald-400 font-medium mb-3">
                    {s.subtitle}
                  </p>
                  <p className="text-sm text-stone-400 leading-relaxed">
                    {s.desc}
                  </p>
                </div>

                <div className="mt-6 pt-3 border-t border-stone-800/80 flex items-center gap-1.5 text-[11px] text-stone-300 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{s.badge}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Button after solution */}
        <div className="mt-14 text-center">
          <button
            type="button"
            onClick={handleCta}
            className="inline-flex items-center gap-2.5 py-3.5 px-8 rounded-xl bg-gradient-to-r from-[#E0A96D] to-[#CCA067] hover:from-[#F0B87C] hover:to-[#DBAE76] text-stone-950 font-bold text-sm shadow-xl transition-all hover:scale-105 active:scale-95 cursor-pointer"
          >
            <span>Quero Proporcionar Esse Cuidado ao Meu Pet</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};
