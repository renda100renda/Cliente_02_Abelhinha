import React from 'react';
import { Check, X, Sparkles, Heart } from 'lucide-react';

export const ComparisonSection: React.FC = () => {
  const comparisonCriteria = [
    {
      criterion: 'Espaço & Convivência',
      aupetmiau: 'Pet solto pela loja, socializando e relaxado',
      traditional: 'Confinamento em gaiolas e baias frias de metal'
    },
    {
      criterion: 'Cães Sensíveis ou Reativos',
      aupetmiau: 'Paciência, respeito ao ritmo e dessensibilização com carinho',
      traditional: 'Contenção forçada ou recusa de atendimento'
    },
    {
      criterion: 'Tosa em Raças Nobres (ex: Spitz)',
      aupetmiau: 'Escultura manual na tesoura preservando o subpêlo',
      traditional: 'Raspagem rápida na máquina (risco de alopécia)'
    },
    {
      criterion: 'Comunicação com o Tutor',
      aupetmiau: 'Envio de fotos e vídeos fofos no WhatsApp a cada banho',
      traditional: 'Nenhuma foto; você só vê o pet na retirada'
    },
    {
      criterion: 'Transporte (Táxi Dog)',
      aupetmiau: 'Motorista cuidadoso, veículo climatizado e aviso em tempo real',
      traditional: 'Transporte amontoado ou terceirizado sem zelo'
    },
    {
      criterion: 'Produtos & Cosmética',
      aupetmiau: 'Linhas nobres hipoalergênicas que protegem a pele',
      traditional: 'Shampoos industriais genéricos comprados em galão'
    }
  ];

  return (
    <section className="py-20 lg:py-24 bg-[#0D1217] relative border-t border-b border-stone-800/70">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3">
            <span>Diferencial Competitivo</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            Por Que Escolher a AUpetMIAU?
          </h2>
          <p className="mt-3 text-stone-400 text-base">
            Compare o padrão boutique & SPA com os métodos de pet shops convencionais e entenda a diferença na prática.
          </p>
        </div>

        {/* Comparison Table */}
        <div className="rounded-2xl border border-stone-800 bg-[#11161D] overflow-hidden shadow-2xl">
          {/* Table Header */}
          <div className="grid grid-cols-12 bg-[#151C24] p-4 sm:p-5 border-b border-stone-800 text-xs sm:text-sm font-bold">
            <div className="col-span-4 sm:col-span-4 text-stone-400 uppercase tracking-wider">
              Critério
            </div>
            <div className="col-span-4 sm:col-span-4 text-[#E0A96D] flex items-center gap-1.5 font-sans">
              <Sparkles className="w-4 h-4 text-[#E0A96D]" />
              <span>AUpetMIAU SPA</span>
            </div>
            <div className="col-span-4 sm:col-span-4 text-stone-400">
              Pet Shops Tradicionais
            </div>
          </div>

          {/* Table Rows */}
          <div className="divide-y divide-stone-800/80">
            {comparisonCriteria.map((item, idx) => (
              <div
                key={idx}
                className="grid grid-cols-12 p-4 sm:p-5 items-center hover:bg-[#151C24]/50 transition-colors text-xs sm:text-sm"
              >
                {/* Criterion */}
                <div className="col-span-4 sm:col-span-4 font-semibold text-stone-200 pr-2">
                  {item.criterion}
                </div>

                {/* AUpetMIAU Cell (Positive) */}
                <div className="col-span-4 sm:col-span-4 pr-3 text-stone-100 flex items-start gap-2 bg-[#E0A96D]/5 py-2 px-2.5 rounded-lg border border-[#E0A96D]/20">
                  <div className="p-0.5 rounded-full bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-medium text-[11px] sm:text-xs leading-relaxed">
                    {item.aupetmiau}
                  </span>
                </div>

                {/* Traditional Pet Shop Cell (Negative) */}
                <div className="col-span-4 sm:col-span-4 pl-2 text-stone-400 flex items-start gap-2">
                  <div className="p-0.5 rounded-full bg-rose-500/10 text-rose-400 shrink-0 mt-0.5">
                    <X className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-[11px] sm:text-xs text-stone-400 leading-relaxed">
                    {item.traditional}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Real Proof Footnote */}
        <div className="mt-6 text-center text-xs text-stone-400 flex items-center justify-center gap-2">
          <Heart className="w-3.5 h-3.5 text-rose-400" />
          <span>Critérios confirmados pelos depoimentos públicos dos nossos tutores no Google Maps.</span>
        </div>

      </div>
    </section>
  );
};
