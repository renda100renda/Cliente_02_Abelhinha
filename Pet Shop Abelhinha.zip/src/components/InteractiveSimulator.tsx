import React, { useState } from 'react';
import { UNITS } from '../data/content';
import { trackConversionEvent, openWhatsAppWithTracking } from '../utils/analytics';
import confetti from 'canvas-confetti';
import { Sparkles, Scissors, Car, Heart, ShieldCheck, ArrowRight, MessageCircle } from 'lucide-react';

interface SimulatorState {
  unit: 'vila-sonia' | 'morumbi';
  petType: 'pequeno' | 'medio' | 'grande' | 'gato';
  petName: string;
  breed: string;
  behavior: 'tranquilo' | 'sensivel' | 'filhote';
  services: string[];
  needTaxiDog: boolean;
  neighborhood: string;
}

export const InteractiveSimulator: React.FC = () => {
  const [state, setState] = useState<SimulatorState>({
    unit: 'vila-sonia',
    petType: 'pequeno',
    petName: '',
    breed: 'Spitz Alemão / Lulu',
    behavior: 'sensivel',
    services: ['Banho SPA com Hidratação', 'Tosa na Tesoura'],
    needTaxiDog: true,
    neighborhood: 'Vila Sônia / Morumbi'
  });

  const toggleService = (service: string) => {
    setState((prev) => {
      const exists = prev.services.includes(service);
      const updated = exists
        ? prev.services.filter((s) => s !== service)
        : [...prev.services, service];
      return { ...prev, services: updated };
    });
  };

  const selectedUnit = UNITS[state.unit];

  // Build tailored WhatsApp message
  const generateWhatsAppMessage = () => {
    const petIdentifier = state.petName ? `meu pet *${state.petName}*` : 'meu pet';
    const breedText = state.breed ? ` (${state.breed})` : '';
    const behaviorNotice =
      state.behavior === 'sensivel'
        ? '\n🐾 *Atenção:* Ele(a) é um cão sensível/reativo com banho fora de casa e precisa de carinho e paciência extra!'
        : state.behavior === 'filhote'
        ? '\n🐾 *Atenção:* É filhote, primeira experiência de banho!'
        : '';

    const taxiText = state.needTaxiDog
      ? `\n🚗 *Gostaria de Táxi Dog Leva & Traz* na região de: ${state.neighborhood || 'Morumbi / Vila Sônia'}`
      : '\n🚗 Vou levar pessoalmente até a loja.';

    const servicesList = state.services.length > 0 ? state.services.join(', ') : 'Banho SPA';

    return encodeURIComponent(
      `Olá, AUpetMIAU (${selectedUnit.name})! 🐾\n` +
      `Gostaria de agendar um horário para ${petIdentifier}${breedText}.\n\n` +
      `✨ *Serviços desejados:* ${servicesList}${behaviorNotice}${taxiText}\n\n` +
      `Vi a nota no Google Maps e adorei o cuidado sem gaiolas. Poderiam me passar os horários disponíveis?`
    );
  };

  const handleBooking = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#E0A96D', '#FFFFFF', '#4E6E5D']
      });
    } catch {
      // ignore
    }

    const text = generateWhatsAppMessage();
    const url = `https://wa.me/${selectedUnit.phoneRaw}?text=${text}`;

    trackConversionEvent('simulator_booking_click', {
      unit: state.unit,
      petType: state.petType,
      petName: state.petName,
      servicesCount: state.services.length,
      needTaxiDog: state.needTaxiDog,
    });

    openWhatsAppWithTracking(url, 'interactive_simulator', selectedUnit.name);
  };

  return (
    <section id="simulador" className="py-20 lg:py-28 relative bg-[#090D10] border-t border-b border-stone-800/80">
      {/* Subtle background ambient light */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-[#E0A96D]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Experiência Personalizada</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100 tracking-tight">
            Monte o SPA Perfeito para o Seu Pet
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            Escolha os cuidados, selecione se precisa do Táxi Dog no seu bairro e inicie o atendimento direto com nossa equipe via WhatsApp.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Controls Column */}
          <div className="lg:col-span-7 bg-[#11171D] border border-stone-800/90 rounded-2xl p-6 sm:p-8 shadow-xl">
            {/* 1. Escolha da Unidade */}
            <div className="mb-7">
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#E0A96D] mb-3">
                1. Selecione a Unidade Mais Próxima
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setState({ ...state, unit: 'vila-sonia' })}
                  className={`p-3.5 rounded-xl text-left border transition-all ${
                    state.unit === 'vila-sonia'
                      ? 'border-[#E0A96D] bg-[#E0A96D]/10 text-white ring-1 ring-[#E0A96D]'
                      : 'border-stone-800 bg-[#0E1318] text-stone-400 hover:border-stone-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm text-stone-200">Vila Sônia</span>
                    <span className="text-xs text-amber-400 font-bold">5.0 ★</span>
                  </div>
                  <p className="text-xs text-stone-400 mt-1 truncate">R. Dr. Sílvio Dante Bertacchi</p>
                </button>

                <button
                  type="button"
                  onClick={() => setState({ ...state, unit: 'morumbi' })}
                  className={`p-3.5 rounded-xl text-left border transition-all ${
                    state.unit === 'morumbi'
                      ? 'border-[#E0A96D] bg-[#E0A96D]/10 text-white ring-1 ring-[#E0A96D]'
                      : 'border-stone-800 bg-[#0E1318] text-stone-400 hover:border-stone-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm text-stone-200">Morumbi / V. Suzana</span>
                    <span className="text-xs text-amber-400 font-bold">4.8 ★</span>
                  </div>
                  <p className="text-xs text-stone-400 mt-1 truncate">R. Mal. Hastimphilo de Moura</p>
                </button>
              </div>
            </div>

            {/* 2. Porte e Nome do Pet */}
            <div className="mb-7">
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#E0A96D] mb-3">
                2. Sobre o Seu Pet
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
                {[
                  { id: 'pequeno', label: 'Porte Pequeno', sub: 'Spitz, Shih-tzu, Maltês' },
                  { id: 'medio', label: 'Porte Médio', sub: 'Beagle, Cocker, Frenchie' },
                  { id: 'grande', label: 'Porte Grande', sub: 'Golden, Labrador, Border' },
                  { id: 'gato', label: 'Gatinho (Felino)', sub: 'Banho calmo e seguro' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setState({ ...state, petType: item.id as SimulatorState['petType'] })}
                    className={`p-3 rounded-xl text-left border text-xs transition-all ${
                      state.petType === item.id
                        ? 'border-[#E0A96D] bg-[#E0A96D]/10 text-white'
                        : 'border-stone-800 bg-[#0E1318] text-stone-400 hover:border-stone-700'
                    }`}
                  >
                    <div className="font-semibold text-stone-200">{item.label}</div>
                    <div className="text-[11px] text-stone-500 mt-0.5">{item.sub}</div>
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-stone-400 mb-1">Nome do Pet (Opcional)</label>
                  <input
                    type="text"
                    value={state.petName}
                    onChange={(e) => setState({ ...state, petName: e.target.value })}
                    placeholder="Ex: Charlie, Malu, Thor..."
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0E1318] border border-stone-800 text-stone-200 text-sm focus:border-[#E0A96D] focus:outline-none focus:ring-1 focus:ring-[#E0A96D]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-stone-400 mb-1">Raça ou Mistura</label>
                  <input
                    type="text"
                    value={state.breed}
                    onChange={(e) => setState({ ...state, breed: e.target.value })}
                    placeholder="Ex: Spitz Alemão, Poodle, SRD..."
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0E1318] border border-stone-800 text-stone-200 text-sm focus:border-[#E0A96D] focus:outline-none focus:ring-1 focus:ring-[#E0A96D]"
                  />
                </div>
              </div>
            </div>

            {/* 3. Perfil Comportamental */}
            <div className="mb-7">
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#E0A96D] mb-3">
                3. Perfil de Comportamento
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'sensivel', title: 'Sensível / Reativo', desc: 'Precisa de paciência e carinho extra' },
                  { id: 'tranquilo', title: 'Tranquilo & Dócil', desc: 'Já é acostumado com banho' },
                  { id: 'filhote', title: 'Filhote / 1ª Vez', desc: 'Adaptação lúdica e acolhedora' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setState({ ...state, behavior: item.id as SimulatorState['behavior'] })}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      state.behavior === item.id
                        ? 'border-emerald-500/70 bg-emerald-500/10 text-white ring-1 ring-emerald-500/40'
                        : 'border-stone-800 bg-[#0E1318] text-stone-400 hover:border-stone-700'
                    }`}
                  >
                    <div className="font-semibold text-xs text-stone-200 flex items-center gap-1.5">
                      {item.id === 'sensivel' && <Heart className="w-3.5 h-3.5 text-rose-400" />}
                      {item.title}
                    </div>
                    <div className="text-[11px] text-stone-400 mt-1">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* 4. Serviços */}
            <div className="mb-7">
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#E0A96D] mb-3">
                4. Serviços de SPA Desejados
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {[
                  { name: 'Banho SPA com Hidratação', icon: Sparkles, hint: 'Cosmética nobre e água na temperatura ideal' },
                  { name: 'Tosa na Tesoura (Padrão)', icon: Scissors, hint: 'Especialistas em Spitz e raças nobres' },
                  { name: 'Tosa Higiênica Delicada', icon: ShieldCheck, hint: 'Patas, barriguinha e partes íntimas' },
                  { name: 'Corte e Lixamento de Unhas', icon: Sparkles, hint: 'Higiene auricular e patas sem machucar' }
                ].map((srv) => {
                  const Icon = srv.icon;
                  const active = state.services.includes(srv.name);
                  return (
                    <button
                      key={srv.name}
                      type="button"
                      onClick={() => toggleService(srv.name)}
                      className={`p-3 rounded-xl text-left border flex items-start gap-3 transition-all ${
                        active
                          ? 'border-[#E0A96D] bg-[#E0A96D]/10 text-white'
                          : 'border-stone-800 bg-[#0E1318] text-stone-400 hover:border-stone-700'
                      }`}
                    >
                      <div className={`p-1.5 rounded-lg ${active ? 'bg-[#E0A96D] text-stone-900' : 'bg-stone-800 text-stone-400'}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-stone-200">{srv.name}</div>
                        <div className="text-[11px] text-stone-400">{srv.hint}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 5. Táxi Dog */}
            <div className="p-4 rounded-xl bg-[#0E1318] border border-stone-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    <Car className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-sm font-semibold text-stone-200">Precisa do Táxi Dog (Leva & Traz)?</span>
                    <p className="text-xs text-stone-400">Motorista carinhoso no Morumbi, Vila Sônia e região</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setState({ ...state, needTaxiDog: !state.needTaxiDog })}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    state.needTaxiDog ? 'bg-[#E0A96D]' : 'bg-stone-700'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      state.needTaxiDog ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              {state.needTaxiDog && (
                <div className="mt-3 pt-3 border-t border-stone-800/80">
                  <label className="block text-[11px] text-stone-400 mb-1">Seu bairro ou condomínio</label>
                  <input
                    type="text"
                    value={state.neighborhood}
                    onChange={(e) => setState({ ...state, neighborhood: e.target.value })}
                    placeholder="Ex: Vila Suzana, Portal do Morumbi, Vila Sônia..."
                    className="w-full px-3 py-2 rounded-lg bg-[#141A21] border border-stone-700 text-stone-200 text-xs focus:border-[#E0A96D] focus:outline-none"
                  />
                </div>
              )}
            </div>
          </div>

          {/* WhatsApp Preview & Direct CTA Column */}
          <div className="lg:col-span-5 lg:sticky lg:top-24">
            <div className="bg-[#121820] border border-[#E0A96D]/30 rounded-2xl p-6 sm:p-7 shadow-2xl relative overflow-hidden glow-gold-subtle">
              <div className="flex items-center justify-between pb-4 border-b border-stone-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                  <div>
                    <span className="text-xs font-semibold text-stone-300 uppercase tracking-wider">
                      Atendimento WhatsApp Imediato
                    </span>
                    <h3 className="text-sm font-bold text-white">{selectedUnit.fullName}</h3>
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-300 font-bold text-xs border border-amber-500/30">
                    {selectedUnit.rating} ★ Google
                  </span>
                </div>
              </div>

              {/* Summary Pills */}
              <div className="my-5 space-y-2.5 text-xs">
                <div className="flex items-center justify-between py-1.5 border-b border-stone-800/60 text-stone-400">
                  <span>Pet:</span>
                  <span className="font-semibold text-stone-200 capitalize">
                    {state.petName || 'Meu Pet'} ({state.breed})
                  </span>
                </div>
                <div className="flex items-center justify-between py-1.5 border-b border-stone-800/60 text-stone-400">
                  <span>Porte:</span>
                  <span className="font-semibold text-stone-200 capitalize">{state.petType}</span>
                </div>
                <div className="flex items-center justify-between py-1.5 border-b border-stone-800/60 text-stone-400">
                  <span>Cuidados Especiais:</span>
                  <span className="font-semibold text-emerald-400">
                    {state.behavior === 'sensivel' ? 'Paciência cão sensível' : 'Padrão carinhoso'}
                  </span>
                </div>
                <div className="flex items-center justify-between py-1.5 border-b border-stone-800/60 text-stone-400">
                  <span>Táxi Dog:</span>
                  <span className="font-semibold text-stone-200">
                    {state.needTaxiDog ? `Sim (${state.neighborhood})` : 'Levar pessoalmente'}
                  </span>
                </div>
              </div>

              {/* Message Bubble Preview */}
              <div className="bg-[#0C1116] rounded-xl p-3.5 border border-stone-800 text-[12px] text-stone-300 mb-6 font-mono leading-relaxed relative">
                <div className="text-[10px] text-stone-500 uppercase tracking-wider mb-1 font-sans">
                  Prévia da Mensagem que será enviada:
                </div>
                <p className="line-clamp-4 italic text-stone-300">
                  &ldquo;Olá, AUpetMIAU! Gostaria de agendar para meu pet {state.petName ? state.petName : ''} ({state.breed}) na unidade {selectedUnit.name}...&rdquo;
                </p>
              </div>

              {/* High-Converting CTA Button */}
              <button
                type="button"
                onClick={handleBooking}
                className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-[#E0A96D] to-[#CCA067] hover:from-[#F0B87C] hover:to-[#DBAE76] text-stone-950 font-bold text-base flex items-center justify-center gap-2.5 shadow-lg transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>Agendar no WhatsApp da {selectedUnit.name}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="mt-4 flex items-center justify-center gap-4 text-[11px] text-stone-400">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Sem gaiolas
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Envio de fotos fofas
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
