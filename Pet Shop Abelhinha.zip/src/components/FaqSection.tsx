import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { FAQ_ITEMS, UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  const handleSupportClick = () => {
    const unit = UNITS['vila-sonia'];
    const msg = encodeURIComponent('Olá, AUpetMIAU! Tenho uma dúvida específica antes de agendar o banho do meu pet.');
    openWhatsAppWithTracking(`https://wa.me/${unit.phoneRaw}?text=${msg}`, 'faq_direct_support', unit.name);
  };

  return (
    <section id="faq" className="py-20 lg:py-28 bg-[#0A0E12] relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Redução de Objeções</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            Antes de Agendar, Talvez Você Esteja Pensando...
          </h2>
          <p className="mt-3 text-stone-400 text-base">
            Perguntas mais frequentes dos tutores que chegam até a AUpetMIAU.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-3.5">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl bg-[#11171E] border border-stone-800 transition-all overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(idx)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-[#151D26]/60 transition-colors"
                >
                  <span className="text-sm sm:text-base font-bold text-stone-100">
                    {item.question}
                  </span>
                  <div
                    className={`w-7 h-7 rounded-full bg-[#18222D] text-[#E0A96D] flex items-center justify-center shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 bg-[#E0A96D] text-stone-950' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-xs sm:text-sm text-stone-300 leading-relaxed border-t border-stone-800/60 animate-in fade-in">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Unanswered questions callout */}
        <div className="mt-12 text-center bg-[#11171E] border border-stone-800 p-6 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h3 className="text-sm font-bold text-white">Ficou com alguma dúvida específica?</h3>
            <p className="text-xs text-stone-400 mt-0.5">
              Nossa equipe no Morumbi e Vila Sônia responde prontamente no WhatsApp.
            </p>
          </div>

          <button
            type="button"
            onClick={handleSupportClick}
            className="py-2.5 px-5 rounded-xl bg-[#18232E] hover:bg-[#E0A96D] text-stone-200 hover:text-stone-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors border border-stone-700 hover:border-[#E0A96D] cursor-pointer"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Tirar Dúvida no WhatsApp</span>
          </button>
        </div>

      </div>
    </section>
  );
};
