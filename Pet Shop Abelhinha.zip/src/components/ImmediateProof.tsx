import React from 'react';
import { Star, Users, Award, Sparkles, Scissors, Car, ShoppingBag, CheckCircle2, ArrowRight, Shield } from 'lucide-react';
import { UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

export const ImmediateProof: React.FC = () => {
  const morumbiUnit = UNITS['morumbi'];

  const handleBookService = (serviceTitle: string) => {
    const msg = encodeURIComponent(
      `Olá, AUpetMIAU! Gostaria de mais informações e agendar o serviço de *${serviceTitle}* no Morumbi / Vila Sônia.`
    );
    openWhatsAppWithTracking(`https://wa.me/${morumbiUnit.phoneRaw}?text=${msg}`, 'service_box_click', morumbiUnit.name);
  };

  const trustMetrics = [
    {
      id: 'rating',
      icon: Star,
      iconColor: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
      value: '4.8 estrelas',
      subvalue: 'de 43 avaliações',
      label: 'Google Maps Morumbi',
      detail: 'Média de 5.0 estrelas na unidade Vila Sônia (129+ reviews totais)'
    },
    {
      id: 'pets',
      icon: Users,
      iconColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
      value: '+500 pets',
      subvalue: 'atendidos com amor',
      label: 'Cuidado Humanizado',
      detail: 'Atendimento calmo, sem confinamento em gaiolas e com respeito ao tempo de cada cão e gato'
    },
    {
      id: 'experience',
      icon: Award,
      iconColor: 'text-[#E0A96D] bg-[#E0A96D]/10 border-[#E0A96D]/20',
      value: '10 anos',
      subvalue: 'de experiência',
      label: 'Em Cuidados Pet',
      detail: 'Especialistas em tosa na tesoura, dermatologia pet e manejo de cães sensíveis ou reativos'
    }
  ];

  const mainServices = [
    {
      id: 'banho-tosa',
      icon: Scissors,
      title: 'Banho & Tosa',
      badge: 'Carinho & Estética Nobre',
      description:
        'Seu pet limpo, cheiroso e com o carinho que ele merece. Banho com água em temperatura agradável, massagem relaxante, produtos hipoalergênicos e tosa anatômica na tesoura sem agredir o subpêlo.',
      perks: [
        'Tosa na tesoura para Spitz Alemão e raças nobres',
        'Secagem silenciosa sem pânico ou soprador estridente',
        'Fotos fofas de estúdio enviadas no WhatsApp'
      ],
      ctaText: 'Agendar Banho & Tosa'
    },
    {
      id: 'taxi-dog',
      icon: Car,
      title: 'Táxi Dog',
      badge: 'Segurança & Pontualidade',
      description:
        'Comodidade e segurança no transporte porta a porta. Buscamos e entregamos seu cãozinho no Morumbi, Vila Suzana, Vila Sônia e região com veículo climatizado, caixas seguras e motorista carinhoso.',
      perks: [
        'Aviso em tempo real pelo WhatsApp na saída e chegada',
        'Veículo higienizado a cada viagem',
        'Zero estresse no trânsito para o tutor e para o pet'
      ],
      ctaText: 'Solicitar Táxi Dog'
    },
    {
      id: 'boutique',
      icon: ShoppingBag,
      title: 'Boutique Pet',
      badge: 'Curadoria Exclusiva',
      description:
        'Acessórios selecionados, roupinhas confortáveis, brinquedos educativos e petiscos nobres para mimar quem você mais ama. Uma seleção cuidadosa feita por veterinárias e especialistas.',
      perks: [
        'Cosmética de alta perfumaria e linha vegana pet',
        'Peitorais anti-puxão ergonômicos e guias seguras',
        'Alimentos naturais e petiscos funcionais'
      ],
      ctaText: 'Conhecer a Boutique'
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-[#0B0F15] border-y border-stone-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* 1. Trust Metrics Area (Números de Confiança) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-20">
          {trustMetrics.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className="p-7 rounded-2xl bg-gradient-to-br from-[#121822] to-[#0E131A] border border-stone-800/90 hover:border-[#E0A96D]/40 transition-all duration-300 shadow-xl flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${item.iconColor} group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400 bg-[#16202B] px-3 py-1 rounded-md border border-stone-800">
                      {item.label}
                    </span>
                  </div>

                  <div className="space-y-0.5">
                    <div className="text-3xl lg:text-4xl font-serif-luxury font-black text-white">
                      {item.value}
                    </div>
                    <div className="text-sm font-semibold text-[#E0A96D]">
                      {item.subvalue}
                    </div>
                  </div>

                  <p className="mt-3 text-xs text-stone-400 leading-relaxed">
                    {item.detail}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* 2. Main Services Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3.5 shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Serviços de Alto Padrão</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            Tudo o Que Seu Pet Precisa em um Só Lugar
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            Combinamos técnica profissional, equipamentos modernos e carinho genuíno para proporcionar a melhor experiência de São Paulo.
          </p>
        </div>

        {/* 3. Main Services Cards Grid (Banho & Tosa, Táxi Dog, Boutique) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {mainServices.map((srv) => {
            const Icon = srv.icon;
            const isHighlight = srv.id === 'banho-tosa';

            return (
              <div
                key={srv.id}
                className={`p-8 rounded-2xl bg-[#121922] border transition-all duration-300 flex flex-col justify-between shadow-2xl relative group ${
                  isHighlight
                    ? 'border-[#E0A96D]/80 ring-1 ring-[#E0A96D]/40 bg-gradient-to-b from-[#151F2C] to-[#101720]'
                    : 'border-stone-800 hover:border-stone-700'
                }`}
              >
                <div>
                  {/* Icon & Badge */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-14 h-14 rounded-2xl bg-[#E0A96D]/10 text-[#E0A96D] flex items-center justify-center border border-[#E0A96D]/25 group-hover:scale-110 group-hover:bg-[#E0A96D] group-hover:text-stone-950 transition-all duration-300 shadow-md">
                      <Icon className="w-7 h-7" />
                    </div>

                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-300 bg-[#17222E] px-2.5 py-1 rounded-md border border-stone-800">
                      {srv.badge}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-2xl font-bold text-stone-100 font-serif-luxury mb-3 group-hover:text-[#E0A96D] transition-colors">
                    {srv.title}
                  </h3>
                  <p className="text-sm text-stone-300 leading-relaxed mb-6">
                    {srv.description}
                  </p>

                  {/* Perks list */}
                  <div className="space-y-2.5 pt-4 border-t border-stone-800/80 mb-6">
                    {srv.perks.map((perk, pIdx) => (
                      <div key={pIdx} className="flex items-start gap-2.5 text-xs text-stone-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{perk}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card CTA Action */}
                <button
                  type="button"
                  onClick={() => handleBookService(srv.title)}
                  className={`w-full py-3.5 px-4 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                    isHighlight
                      ? 'bg-gradient-to-r from-[#E0A96D] to-[#CCA067] hover:from-[#F0B87C] hover:to-[#DBAE76] text-stone-950'
                      : 'bg-[#182330] hover:bg-[#E0A96D] text-stone-200 hover:text-stone-950 border border-stone-700 hover:border-[#E0A96D]'
                  }`}
                >
                  <span>{srv.ctaText}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Footnote reassurance */}
        <div className="mt-14 text-center">
          <div className="inline-flex items-center gap-2 text-xs text-stone-400 bg-[#121922] px-5 py-2 rounded-full border border-stone-800">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Todos os serviços contam com supervisão atenta e acompanhamento fotográfico no WhatsApp.</span>
          </div>
        </div>

      </div>
    </section>
  );
};
