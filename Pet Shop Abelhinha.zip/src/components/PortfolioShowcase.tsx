import React, { useState } from 'react';
import { Camera, Sparkles, Scissors, Eye, Heart, X } from 'lucide-react';
import { UNITS } from '../data/content';
import { openWhatsAppWithTracking } from '../utils/analytics';

interface ShowcaseItem {
  id: string;
  title: string;
  breed: string;
  tag: string;
  imageUrl: string;
  details: string;
  result: string;
}

export const PortfolioShowcase: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState<ShowcaseItem | null>(null);

  const showcaseItems: ShowcaseItem[] = [
    {
      id: 'spitz',
      title: 'Tosa na Tesoura Padrão da Raça',
      breed: 'Spitz Alemão (Lulu da Pomerânia)',
      tag: 'Especialidade AUpetMIAU',
      imageUrl: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=800&q=80',
      details: 'Tosa anatômica 100% feita na tesoura, respeitando a camada dupla de subpêlo essencial para a proteção térmica. O cão fica com contorno arredondado, volume fofo e livre do risco de alopécia pós-tosa.',
      result: 'Pelagem protegida, volumosa e sedosa por semanas.'
    },
    {
      id: 'shihtzu',
      title: 'Tosa Bebê & Higiênica Confortável',
      breed: 'Shih-tzu / Maltês',
      tag: 'Estilo & Praticidade',
      imageUrl: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=800&q=80',
      details: 'Corte facial delicado que valoriza o olhar expressivo, higiene completa nas patinhas e barriga, e finalização com máscara nutritiva para evitar nós no dia a dia.',
      result: 'Rostinho limpo, sem lacrimejamento escuro e fácil de escovar.'
    },
    {
      id: 'golden',
      title: 'SPA Hidratante & Remoção de Subpêlo',
      breed: 'Golden Retriever / Porte Grande',
      tag: 'Banho SPA Revitalizante',
      imageUrl: 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=800&q=80',
      details: 'Banho com água morna terapêutica, hidratação profunda para pelagens densas e soprador com controle acústico para remover pelos mortos sem irritar a audição do pet.',
      result: 'Redução drástica de pelos pela casa e brilho dourado exuberante.'
    },
    {
      id: 'fotos',
      title: 'A Sessão de Fotos Fofas no WhatsApp',
      breed: 'Todos os Pets Atendidos',
      tag: 'Transparência Afetiva',
      imageUrl: 'https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?auto=format&fit=crop&w=800&q=80',
      details: 'Assim que o banho termina e o lacinho boutique é colocado, nossa equipe tira fotos e vídeos em alta definição do seu pet e manda direto no seu WhatsApp para você morrer de amores.',
      result: 'Você recebe o resultado em tempo real no seu celular.'
    }
  ];

  const handleBookGrooming = (item: ShowcaseItem) => {
    const unit = UNITS['vila-sonia'];
    const msg = encodeURIComponent(
      `Olá, AUpetMIAU! Vi o estilo de ${item.title} (${item.breed}) no site e gostaria de agendar esse mesmo cuidado para meu pet!`
    );
    openWhatsAppWithTracking(`https://wa.me/${unit.phoneRaw}?text=${msg}`, 'portfolio_modal_booking', unit.name);
  };

  return (
    <section className="py-20 lg:py-28 bg-[#0D1217] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3">
            <Camera className="w-3.5 h-3.5" />
            <span>Nossos Resultados Reais</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            A Arte da Tosa e o Brilho de Quem é Cuidado com Amor
          </h2>
          <p className="mt-3 text-stone-400 text-base sm:text-lg">
            Passe o mouse ou toque nos cards para conhecer a técnica e os cuidados específicos aplicados em cada estilo.
          </p>
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {showcaseItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedItem(item)}
              className="group relative rounded-2xl overflow-hidden bg-[#11171E] border border-stone-800 hover:border-[#E0A96D]/60 transition-all duration-300 shadow-xl cursor-pointer"
            >
              {/* Image Container */}
              <div className="relative aspect-[4/5] overflow-hidden bg-stone-900">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

                {/* Top Badge */}
                <div className="absolute top-3 left-3 bg-[#11161D]/80 backdrop-blur-md px-2.5 py-1 rounded-md text-[10px] font-bold text-[#E0A96D] border border-stone-800">
                  {item.tag}
                </div>

                {/* Hover Eye Trigger */}
                <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur-md text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Eye className="w-4 h-4" />
                </div>

                {/* Bottom Content Info */}
                <div className="absolute bottom-0 inset-x-0 p-5 text-left">
                  <span className="text-[11px] font-semibold text-emerald-400 block mb-1">
                    {item.breed}
                  </span>
                  <h3 className="text-base font-bold text-white group-hover:text-[#E0A96D] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-stone-400 line-clamp-2 mt-1">
                    {item.details}
                  </p>
                  <div className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-[#E0A96D]">
                    <span>Ver detalhes do cuidado</span>
                    <span>→</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal for Details when clicked */}
        {selectedItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
            <div className="relative w-full max-w-lg rounded-2xl bg-[#121820] border border-stone-700 p-6 sm:p-8 shadow-2xl">
              <button
                onClick={() => setSelectedItem(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-stone-800 text-stone-300 hover:text-white"
                aria-label="Fechar"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="aspect-video w-full rounded-xl overflow-hidden mb-5">
                <img
                  src={selectedItem.imageUrl}
                  alt={selectedItem.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <span className="text-xs font-bold uppercase tracking-wider text-[#E0A96D] block mb-1">
                {selectedItem.tag} · {selectedItem.breed}
              </span>
              <h3 className="text-xl font-bold text-white mb-3">
                {selectedItem.title}
              </h3>
              <p className="text-sm text-stone-300 leading-relaxed mb-4">
                {selectedItem.details}
              </p>

              <div className="p-3.5 rounded-xl bg-[#0B0F13] border border-stone-800 text-xs text-emerald-300 font-medium mb-6">
                ✨ <strong>Resultado esperado:</strong> {selectedItem.result}
              </div>

              <button
                type="button"
                onClick={() => handleBookGrooming(selectedItem)}
                className="w-full py-3.5 rounded-xl bg-[#E0A96D] hover:bg-[#F0B87C] text-stone-950 font-bold text-sm flex items-center justify-center gap-2 cursor-pointer shadow-lg"
              >
                <Scissors className="w-4 h-4" />
                <span>Quero Esse Estilo de Tosa no Meu Pet</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
