import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Heart, Scissors, Camera, CheckCircle2, ArrowRight, ShieldCheck, ChevronRight, Volume2 } from 'lucide-react';

interface StoryStep {
  id: string;
  stepNumber: string;
  phase: string;
  title: string;
  subtitle: string;
  description: string;
  expertLegend: string;
  behindTheScenes: string;
  tag: string;
  imageUrl: string;
  bgGlow: string;
}

export const CarinhoEmAcaoStorytelling: React.FC = () => {
  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const steps: StoryStep[] = [
    {
      id: 'chegada',
      stepNumber: '01',
      phase: 'A Chegada',
      title: 'Chegada Acolhedora: Pet Solto & Sem Gaiolas',
      subtitle: 'Zero confinamento metálico, 100% respeito ao tempo do seu pet',
      description:
        'O pet entra no nosso espaço e não vai direto para a banheira. Ele passeia solto pela loja climatizada, cheira os cantinhos, ganha carinho da equipe e recebe um petisco hipoalergênico para associar o local a coisas boas.',
      expertLegend:
        '“Abaixamos no nível dos olhos do pet e deixamos ele se aproximar voluntariamente. Cães tímidos ou reativos ganham tempo para se acalmar sem nenhuma pressão física.”',
      behindTheScenes:
        'Ambiente com difusor de feromônios calmantes naturais e temperatura estável em 22°C.',
      tag: 'Dessensibilização Positiva',
      imageUrl:
        'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=1000&q=85',
      bgGlow: 'from-amber-500/10 via-emerald-500/5 to-transparent'
    },
    {
      id: 'banho',
      stepNumber: '02',
      phase: 'O Banho SPA',
      title: 'Banho SPA: Água Morninha, Massagem & Pele Protegida',
      subtitle: 'Higiene com cosmética nobre e secadores de baixíssimo ruído',
      description:
        'A água é ajustada em temperatura ideal para o relaxamento muscular. Utilizamos xampus hipoalergênicos de alta perfumaria com pH neutro, máscaras nutritivas e massagem suave na cabeça e patinhas.',
      expertLegend:
        '“Secamos os ouvidos e olhos com toalhas ultra absorventes antes do soprador. Nossos equipamentos possuem isolamento acústico para não assustar o ouvido canino.”',
      behindTheScenes:
        'Água filtrada com pressão suave e escovação prévia com desembaraçador suave.',
      tag: 'Alta Cosmética Pet',
      imageUrl:
        'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?auto=format&fit=crop&w=1000&q=85',
      bgGlow: 'from-blue-500/10 via-[#E0A96D]/5 to-transparent'
    },
    {
      id: 'tosa',
      stepNumber: '03',
      phase: 'A Tosa',
      title: 'Tosa na Tesoura: Escultura Anatômica no Padrão da Raça',
      subtitle: 'Proteção do subpêlo essencial contra alopécia pós-tosa',
      description:
        'Especialidade consagrada da AUpetMIAU: tosa minuciosa realizada 100% na tesoura para raças de pelagem dupla como Spitz Alemão (Lulu), além de cortes personalizados para Poodle, Maltês e Shih-tzu.',
      expertLegend:
        '“Não passamos máquina raspando a pele do Spitz, pois isso destrói os folículos do subpêlo. Esculpimos o contorno arredondado fio a fio com tesouras curvas japonesas.”',
      behindTheScenes:
        'Groomers com certificações internacionais em padrão de raça e bem-estar animal.',
      tag: 'Escultura Manual Fio a Fio',
      imageUrl:
        'https://images.unsplash.com/photo-1535294435445-d7249524ef2e?auto=format&fit=crop&w=1000&q=85',
      bgGlow: 'from-[#E0A96D]/15 via-rose-500/5 to-transparent'
    },
    {
      id: 'finalizacao',
      stepNumber: '04',
      phase: 'O Retorno',
      title: 'Limpo, Cheiroso & Feliz: Fotos no WhatsApp e Retorno VIP',
      subtitle: 'O tutor acompanha tudo e recebe o pet com alegria plena',
      description:
        'Ao finalizar o banho, seu pet ganha lacinho ou gravatinha boutique, faz pose no nosso estúdio fotográfico e enviamos as fotos em alta resolução direto no seu WhatsApp antes do retorno seguro no Táxi Dog.',
      expertLegend:
        '“A maior recompensa é ver o pet saindo abanando o rabo, relaxado e querendo dar beijo na equipe. Aqui o banho é sinônimo de dia de festa.”',
      behindTheScenes:
        'Perfume hipoalergênico suave que dura até 10 dias sem causar espirros no animal.',
      tag: 'Transparência Afetiva',
      imageUrl:
        'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=1000&q=85',
      bgGlow: 'from-emerald-500/10 via-[#E0A96D]/10 to-transparent'
    }
  ];

  const currentStep = steps[activeStepIndex];

  // Auto progression if user wants to watch the story
  useEffect(() => {
    if (!autoPlay) return;
    const interval = setInterval(() => {
      setActiveStepIndex((prev) => (prev + 1) % steps.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [autoPlay, steps.length]);

  const handleNext = () => {
    setActiveStepIndex((prev) => (prev + 1) % steps.length);
  };

  const handlePrev = () => {
    setActiveStepIndex((prev) => (prev - 1 + steps.length) % steps.length);
  };

  const scrollToSpaPackages = () => {
    const el = document.getElementById('servicos') || document.getElementById('simulador');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="carinho-em-acao"
      ref={containerRef}
      className="py-20 lg:py-32 bg-[#090D13] relative overflow-hidden border-t border-stone-800/80"
    >
      {/* Dynamic Background Glow changing with current stage */}
      <div
        className={`absolute inset-0 bg-gradient-to-br ${currentStep.bgGlow} transition-colors duration-1000 pointer-events-none`}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3.5 shadow-sm">
            <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
            <span>Carinho em Ação · Scroll Storytelling</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif-luxury font-bold text-stone-100 leading-tight">
            Como Transformamos o Banho em um Momento de Puro Afeto
          </h2>
          <p className="mt-4 text-stone-400 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
            Acompanhe passo a passo a experiência do seu melhor amigo na AUpetMIAU: da recepção afetuosa sem gaiolas ao retorno cheiroso e feliz.
          </p>

          {/* Step Selector Buttons Bar */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            {steps.map((s, idx) => {
              const isActive = activeStepIndex === idx;
              return (
                <button
                  key={s.id}
                  onClick={() => {
                    setActiveStepIndex(idx);
                    setAutoPlay(false);
                  }}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md ${
                    isActive
                      ? 'bg-gradient-to-r from-[#E0A96D] to-[#CCA067] text-stone-950 scale-105 ring-2 ring-[#E0A96D]/40'
                      : 'bg-[#131922] hover:bg-[#1A2330] text-stone-300 border border-stone-800'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                    isActive ? 'bg-stone-950 text-[#E0A96D]' : 'bg-stone-800 text-stone-400'
                  }`}>
                    {s.stepNumber}
                  </span>
                  <span>{s.phase}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Storytelling Interactive Stage */}
        <div className="bg-[#101720]/90 border border-stone-800 rounded-3xl p-6 sm:p-8 lg:p-10 shadow-2xl relative overflow-hidden backdrop-blur-md">
          
          {/* Top Stage Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-stone-800/80">
            <div className="flex items-center gap-3">
              <span className="text-2xl font-serif-luxury font-black text-[#E0A96D]">
                Etapa {currentStep.stepNumber} <span className="text-sm font-normal text-stone-500">/ 04</span>
              </span>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-[#16212E] text-emerald-300 border border-stone-700">
                {currentStep.tag}
              </span>
            </div>

            {/* Stage Navigation & Autoplay Toggle */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setAutoPlay(!autoPlay)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                  autoPlay
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-[#151D27] text-stone-400 border-stone-800 hover:text-white'
                }`}
              >
                {autoPlay ? '▶ Reproduzindo história...' : 'Autoplay'}
              </button>

              <button
                type="button"
                onClick={handlePrev}
                className="p-2 rounded-lg bg-[#151D27] text-stone-300 hover:text-white border border-stone-800 hover:border-stone-700"
                aria-label="Etapa anterior"
              >
                ←
              </button>
              <button
                type="button"
                onClick={handleNext}
                className="p-2 rounded-lg bg-[#E0A96D] text-stone-950 font-bold hover:bg-[#F0B87C] shadow-md transition-colors"
                aria-label="Próxima etapa"
              >
                →
              </button>
            </div>
          </div>

          {/* Main Content Layout: Side-by-side Image & Deep Story Narrative */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center pt-8">
            
            {/* Left: Dynamic Visual Showcase with smooth cross-fade */}
            <div className="lg:col-span-6 relative">
              <div className="relative aspect-[4/3] sm:aspect-[16/11] rounded-2xl overflow-hidden border border-stone-700/80 shadow-2xl bg-stone-950 group">
                <img
                  key={currentStep.id}
                  src={currentStep.imageUrl}
                  alt={currentStep.title}
                  className="w-full h-full object-cover object-center transition-all duration-700 group-hover:scale-105 animate-in fade-in"
                />
                
                {/* Visual Glass Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-stone-950/20 to-transparent" />

                {/* Floating Behind the Scenes Micro-badge */}
                <div className="absolute bottom-4 inset-x-4 p-3 rounded-xl bg-[#11171E]/95 backdrop-blur-md border border-stone-800 text-xs text-stone-300 shadow-xl flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-[#E0A96D] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-stone-100 block text-[11px] uppercase tracking-wider text-[#E0A96D]">
                      Bastidor da Equipe:
                    </span>
                    <span className="text-stone-300 leading-snug">
                      {currentStep.behindTheScenes}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Rich Storytelling Text & Expertise Legends */}
            <div className="lg:col-span-6 space-y-6">
              
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-[#E0A96D] mb-1.5">
                  {currentStep.subtitle}
                </p>
                <h3 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-stone-100 leading-snug">
                  {currentStep.title}
                </h3>
              </div>

              {/* Step Description */}
              <p className="text-sm sm:text-base text-stone-300 leading-relaxed">
                {currentStep.description}
              </p>

              {/* Expert Groomer Quote / Legenda de Cuidado & Expertise */}
              <div className="p-4 sm:p-5 rounded-2xl bg-[#141E28] border border-[#E0A96D]/25 relative">
                <div className="flex items-center gap-2 mb-2 text-[#E0A96D] text-xs font-bold uppercase tracking-wider">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Cuidado & Expertise Técnica</span>
                </div>
                <p className="text-xs sm:text-sm text-stone-200 italic leading-relaxed">
                  {currentStep.expertLegend}
                </p>
                <div className="mt-2 text-[11px] text-stone-400 font-medium">
                  — Equipe de Grooming & Bem-Estar AUpetMIAU
                </div>
              </div>

              {/* Mini Indicators */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="flex items-center gap-2 text-xs text-stone-300 bg-[#141C25] p-2.5 rounded-xl border border-stone-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Sem amarras forçadas</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-stone-300 bg-[#141C25] p-2.5 rounded-xl border border-stone-800">
                  <CheckCircle2 className="w-4 h-4 text-[#E0A96D] shrink-0" />
                  <span>Ritmo de cada pet</span>
                </div>
              </div>

            </div>

          </div>

          {/* End of Section: Secondary CTA as requested */}
          <div className="mt-12 pt-8 border-t border-stone-800/80 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="text-center sm:text-left">
              <h4 className="text-base font-bold text-stone-100 flex items-center justify-center sm:justify-start gap-2">
                <Sparkles className="w-4 h-4 text-[#E0A96D]" />
                Gostou de conhecer o nosso processo de cuidado?
              </h4>
              <p className="text-xs text-stone-400 mt-1">
                Temos planos avulsos e pacotes mensais de SPA com desconto e Táxi Dog incluso.
              </p>
            </div>

            {/* Secondary CTA: 'Veja nossos pacotes de SPA' */}
            <button
              type="button"
              onClick={scrollToSpaPackages}
              className="py-3.5 px-7 rounded-xl bg-gradient-to-r from-[#E0A96D] to-[#CCA067] hover:from-[#F0B87C] hover:to-[#DBAE76] text-stone-950 font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2.5 shadow-xl transition-transform hover:scale-105 active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>Veja nossos pacotes de SPA</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};
