import React, { useState, useRef } from 'react';
import { Sparkles, Scissors, Heart } from 'lucide-react';

export const BeforeAfterSlider: React.FC = () => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    handleMove(e.touches[0].clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    handleMove(e.clientX);
  };

  return (
    <section className="py-20 lg:py-24 bg-[#0B0F13] relative border-b border-stone-800/60">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0A96D]/10 border border-[#E0A96D]/30 text-[#E0A96D] text-xs font-semibold tracking-wider uppercase mb-3">
            <Scissors className="w-3.5 h-3.5" />
            <span>Arte na Tesoura & Alta Cosmética</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-stone-100">
            A Transformação do Ritual Boutique & SPA
          </h2>
          <p className="mt-3 text-stone-400 text-base">
            Arraste o divisor para ver a diferença que a tosa no padrão da raça e cosméticos nobres fazem na pelagem e bem-estar do seu cão.
          </p>
        </div>

        {/* Interactive Comparison Card */}
        <div className="max-w-4xl mx-auto">
          <div
            ref={containerRef}
            className="relative h-[380px] sm:h-[480px] rounded-2xl overflow-hidden shadow-2xl border border-stone-800 cursor-ew-resize select-none"
            onMouseDown={() => setIsDragging(true)}
            onMouseUp={() => setIsDragging(false)}
            onMouseLeave={() => setIsDragging(false)}
            onMouseMove={handleMouseMove}
            onTouchStart={() => setIsDragging(true)}
            onTouchEnd={() => setIsDragging(false)}
            onTouchMove={handleTouchMove}
          >
            {/* "DEPOIS" (Right background image - Full width) */}
            <div className="absolute inset-0 bg-[#162029]">
              <img
                src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=1400&q=80"
                alt="Pet após banho e tosa na AUpetMIAU"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />
              <div className="absolute top-4 right-4 bg-emerald-500/90 text-stone-950 font-bold text-xs uppercase px-3 py-1.5 rounded-full shadow-lg flex items-center gap-1.5 backdrop-blur-sm">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Depois: SPA & Tosa AUpetMIAU</span>
              </div>
              <div className="absolute bottom-6 right-6 max-w-xs text-right bg-stone-950/70 backdrop-blur-md p-3.5 rounded-xl border border-emerald-500/30 hidden sm:block">
                <p className="text-xs font-semibold text-emerald-300">Padrão da Raça na Tesoura</p>
                <p className="text-[11px] text-stone-300 mt-0.5">
                  Pelagem escovada, subpêlo preservado, volume sedoso e cheirinho duradouro.
                </p>
              </div>
            </div>

            {/* "ANTES" (Left clipped layer) */}
            <div
              className="absolute inset-y-0 left-0 overflow-hidden bg-[#10151C]"
              style={{ width: `${sliderPosition}%` }}
            >
              <div
                className="absolute inset-0"
                style={{ width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%' }}
              >
                <img
                  src="https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=1400&q=80"
                  alt="Pet antes do banho"
                  className="w-full h-full object-cover object-center filter saturate-75 brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />
                <div className="absolute top-4 left-4 bg-stone-800/90 text-stone-300 font-bold text-xs uppercase px-3 py-1.5 rounded-full shadow-lg backdrop-blur-sm border border-stone-700">
                  <span>Antes da Visita</span>
                </div>
                <div className="absolute bottom-6 left-6 max-w-xs text-left bg-stone-950/70 backdrop-blur-md p-3.5 rounded-xl border border-stone-800 hidden sm:block">
                  <p className="text-xs font-semibold text-stone-300">Pelagem Desalinhada & Opaca</p>
                  <p className="text-[11px] text-stone-400 mt-0.5">
                    Pelos embolando, patinhas sujas e sem a hidratação que a pele precisa.
                  </p>
                </div>
              </div>
            </div>

            {/* Draggable Divider Handle */}
            <div
              className="absolute inset-y-0 w-1 bg-white cursor-ew-resize shadow-[0_0_15px_rgba(255,255,255,0.8)]"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-white text-stone-900 flex items-center justify-center shadow-xl border-2 border-[#E0A96D]">
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="m9 18-6-6 6-6" />
                  <path d="m15 6 6 6-6 6" />
                </svg>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4 text-xs text-stone-400 px-2">
            <span>‹ Deslize para a esquerda para ver mais do Antes</span>
            <span className="flex items-center gap-1 text-[#E0A96D]">
              <Heart className="w-3.5 h-3.5 fill-current" /> Especialistas em Spitz Alemão & Raças Nobres
            </span>
            <span>Deslize para a direita para ver o Depois ›</span>
          </div>
        </div>
      </div>
    </section>
  );
};
